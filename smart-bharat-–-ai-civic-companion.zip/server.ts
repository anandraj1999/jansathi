import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Body parser
app.use(express.json());

// Lazy-loaded Gemini API Client
let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not defined in the environment. Please add it via Secrets or .env file.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// System instructions that enforce persona and intent-routing
const SYSTEM_INSTRUCTION = `
You are "JanSathi AI Civic Companion", a friendly, highly knowledgeable, and polite civic assistant for Indian citizens. Your core role is to simplify civic processes, help citizens raise structured complaints, guide them on documents, and find government schemes.

For EVERY user message, detect their intent and map it to one of these 4 intents:
1. GENERAL_QUERY: The user has a generic question about government systems, municipal services, civic processes, or citizen rights (e.g., "what is municipal corporation?"). Explain in simple, plain, jargon-free English, Hindi, or Hinglish.
2. COMPLAINT: The user wants to report a civic issue (roads, water, electricity, sanitation, garbage, public hazard). 
   - Extract:
     - Category: must be one of ["Roads", "Water", "Electricity", "Sanitation", "Garbage", "Other"]
     - Location: The user's specific area or address. If NOT provided, set status to "Incomplete" and prompt them politely to provide the location in replyText.
     - Description: Details of the issue.
     - Urgency: ["Low", "Medium", "High"] based on safety/health risk. High is for severe physical hazards (open transformers, open manholes, active water leakage blocking traffic, large road sinkholes). Low/Medium is for aesthetic/maintenance issues (garbage pile, slow water, minor potholes).
   - If BOTH location and description are present, generate a unique complaint ID: "JS-COMP-XXXX" (where XXXX is a random 4-digit number) and set status to "Ready".
3. DOCUMENT_HELP: The user wants help getting/updating an Indian government document (e.g., Aadhaar card, PAN card, passport, driving license, birth certificate, ration card).
   - Extract: Document name.
   - Return:
     - Checklist: precise step-by-step required documents (e.g., Proof of Address, Proof of Identity).
     - Processing Time: e.g., "7-10 working days".
     - Official Portal: The exact portal name (do not invent URLs, say "Search on official Passport Seva website" or "UIDAI portal").
4. SCHEME_FINDER: The user is looking for government schemes they qualify for.
   - We need to know: Age, Occupation (e.g., Farmer, Student, Self-employed, Retired), Income bracket, and State.
   - If any of these are missing, ask 3-4 short questions to get this information in your replyText.
   - If they are provided, recommend 2-3 matched, highly relevant Indian central/state schemes (like PM-KISAN, Atal Pension Yojana, Sukanya Samriddhi Yojana, PM SVANidhi, PM-AWAS, Ayushman Bharat, National Social Assistance Program, etc.) with brief eligibility and benefits.

LANGUAGE GUIDELINES:
- Always respond in the exact language style and script the user wrote in (English, Hindi, or Hinglish - Hindi written in Latin script, e.g., "Mera road kharab hai").
- The replyText MUST be written fully in that detected language style.
- Maintain an extremely helpful, polite, and encouraging tone ("Aap" in Hindi/Hinglish).

DISCLAIMER:
- At the end of every replyText containing factual government information or processes, include this exact footer message: "\\n\\n*Please verify details on the official government portal.*"
`;

// Define the response schema matching the TS schema
const RESPONSE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    intent: {
      type: Type.STRING,
      description: "Must be one of: GENERAL_QUERY, COMPLAINT, DOCUMENT_HELP, SCHEME_FINDER",
    },
    replyText: {
      type: Type.STRING,
      description: "The primary conversational response to show to the user. Same language as user input.",
    },
    language: {
      type: Type.STRING,
      description: "Detected language: 'en', 'hi', or 'hinglish'",
    },
    complaintData: {
      type: Type.OBJECT,
      description: "Required if intent is COMPLAINT. Otherwise omit.",
      properties: {
        category: { type: Type.STRING, description: "Must be: Roads, Water, Electricity, Sanitation, Garbage, or Other" },
        location: { type: Type.STRING, description: "Extracted specific location/landmark, or 'missing' if not provided." },
        description: { type: Type.STRING, description: "Extracted details of the complaint" },
        urgency: { type: Type.STRING, description: "Low, Medium, or High" },
        complaintId: { type: Type.STRING, description: "Unique complaint ID like JS-COMP-3914, omit or leave empty if status is 'Incomplete'" },
        status: { type: Type.STRING, description: "Either 'Ready' (if location and description are present) or 'Incomplete' (if location is missing)" }
      }
    },
    documentHelpData: {
      type: Type.OBJECT,
      description: "Required if intent is DOCUMENT_HELP. Otherwise omit.",
      properties: {
        documentName: { type: Type.STRING, description: "Name of the requested document" },
        checklist: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "Required physical or digital documents checklist"
        },
        processingTime: { type: Type.STRING, description: "Approximate days or weeks" },
        officialPortalName: { type: Type.STRING, description: "Exact name of the official government portal" }
      }
    },
    schemeFinderData: {
      type: Type.OBJECT,
      description: "Required if intent is SCHEME_FINDER. Otherwise omit.",
      properties: {
        questionsAsked: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "List of short questions asked to collect missing info (age, occupation, income, state)"
        },
        recommendedSchemes: {
          type: Type.ARRAY,
          description: "List of recommended schemes if key attributes are available",
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING, description: "Name of the government scheme" },
              eligibility: { type: Type.STRING, description: "One-line eligibility description" },
              benefits: { type: Type.STRING, description: "Key benefits of the scheme" }
            }
          }
        }
      }
    }
  },
  required: ["intent", "replyText", "language"]
};

// API Endpoint for Chat and civic intelligence routing
app.post("/api/chat", async (req, res) => {
  try {
    const { message, history } = req.body;
    if (!message || typeof message !== "string") {
      return res.status(400).json({ error: "Message is required and must be a string." });
    }

    // Format chat history for Gemini API
    const formattedContents = [];
    if (Array.isArray(history)) {
      for (const item of history) {
        if (item.role === "user" || item.role === "model") {
          formattedContents.push({
            role: item.role,
            parts: [{ text: item.text }],
          });
        }
      }
    }

    // Add current user message
    formattedContents.push({
      role: "user",
      parts: [{ text: message }],
    });

    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: formattedContents,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: RESPONSE_SCHEMA,
        temperature: 0.2, // low temperature for precise classification and compliance
      },
    });

    const textOutput = response.text;
    if (!textOutput) {
      throw new Error("Received empty response from Gemini API.");
    }

    const parsedJson = JSON.parse(textOutput);
    res.json(parsedJson);

  } catch (error: any) {
    console.error("API error in /api/chat:", error);
    res.status(500).json({
      error: error.message || "An unexpected error occurred. Please try again.",
    });
  }
});

// Configure Vite middleware or static serving
async function setupViteOrStatic() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Vite development server middleware loaded.");
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log("Serving static files from /dist in production.");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Smart Bharat server listening on http://localhost:${PORT}`);
  });
}

setupViteOrStatic();
