import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Send, 
  RotateCcw, 
  AlertTriangle, 
  Award, 
  FileText, 
  Globe, 
  HelpCircle, 
  Languages, 
  Check, 
  Copy, 
  Trash2, 
  User, 
  Bot, 
  Sparkles, 
  Loader2,
  CheckCircle2,
  MapPin,
  Clock,
  ArrowRight,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  LogOut,
  ThumbsUp,
  ThumbsDown,
  Radio,
  Ear
} from "lucide-react";

import { ComplaintCard, ComplaintData } from "./components/ComplaintCard";
import { SchemeCard, Scheme } from "./components/SchemeCard";
import { DocumentChecklist, DocumentHelpData } from "./components/DocumentChecklist";
import { ValidationSuite } from "./components/ValidationSuite";
import { AuthScreen } from "./components/AuthScreen";
import { FaqTab } from "./components/FaqTab";
import { WelcomeAvatar3D } from "./components/WelcomeAvatar3D";
import { MovingTricolorWave } from "./components/MovingTricolorWave";
import { translations } from "./translations";

interface ChatMessage {
  id: string;
  role: "user" | "model";
  text: string;
  intent?: "GENERAL_QUERY" | "COMPLAINT" | "DOCUMENT_HELP" | "SCHEME_FINDER";
  complaintData?: ComplaintData;
  documentHelpData?: DocumentHelpData;
  schemeFinderData?: {
    questionsAsked?: string[];
    recommendedSchemes?: Scheme[];
  };
  feedback?: "like" | "dislike" | null;
  timestamp: Date;
}

// Highly stylized animated 3D-looking Robot holding phone logo
function AnimatedRobotLogo({ isListening, isResponding, isSpeaking }: { isListening: boolean; isResponding: boolean; isSpeaking: boolean }) {
  return (
    <div className="relative w-11 h-11 flex items-center justify-center shrink-0 group">
      {/* Holographic glowing back-ring */}
      <div className={`absolute inset-0 rounded-full bg-gradient-to-tr from-orange-500 via-indigo-500 to-emerald-500 opacity-20 blur-md transition-all duration-700 ${
        isListening ? "scale-125 opacity-40 animate-pulse" : isResponding ? "animate-spin scale-110 opacity-30" : isSpeaking ? "scale-115 opacity-30" : "group-hover:scale-110 group-hover:opacity-30"
      }`} />
      
      {/* Dashed high-tech spinning circle */}
      <div className={`absolute inset-0 rounded-full border border-dashed border-indigo-400/30 transition-all duration-1000 ${
        isResponding ? "animate-spin" : "animate-[spin_10s_linear_infinite]"
      }`} />

      {/* Main glass-ring container */}
      <div className="relative w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 overflow-hidden flex items-center justify-center shadow-inner shadow-indigo-500/15">
        <img 
          src="/src/assets/images/jansathi_robot_logo_1783407583645.jpg" 
          alt="JanSathi 3D Logo" 
          referrerPolicy="no-referrer"
          className={`w-full h-full object-cover transition-transform duration-500 ${
            isListening ? "scale-110 rotate-3" : isResponding ? "scale-105 -rotate-3" : isSpeaking ? "scale-105 animate-pulse" : "group-hover:scale-105"
          }`}
        />
        
        {/* Color overlays based on state */}
        {isListening && (
          <div className="absolute inset-0 bg-rose-500/20 flex items-center justify-center">
            <span className="w-1.5 h-1.5 bg-rose-500 rounded-full animate-ping" />
          </div>
        )}
        {isSpeaking && (
          <div className="absolute inset-0 bg-indigo-500/20 flex items-center justify-center">
            <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-ping" />
          </div>
        )}
      </div>

      {/* Floating 3D Phone Badge */}
      <div className="absolute -bottom-1 -right-1 w-4.5 h-4.5 rounded-md bg-gradient-to-br from-indigo-500 to-cyan-500 border border-slate-900 flex items-center justify-center shadow-md shadow-indigo-500/30">
        <svg className="w-2.5 h-2.5 text-white animate-bounce" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="3">
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 18.5a1.5 1.5 0 100-3 1.5 1.5 0 000 3z" />
          <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5H15.75A2.25 2.25 0 0118 6.75v10.5A2.25 2.25 0 0115.75 19.5H8.25A2.25 2.25 0 016 17.25V6.75A2.25 2.25 0 018.25 4.5z" />
        </svg>
      </div>
    </div>
  );
}

export default function App() {
  const [lang, setLang] = useState<"en" | "hi">("en");
  const [activeTab, setActiveTab] = useState<"chat" | "complaints" | "schemes" | "documents" | "tests" | "faqs">("chat");
  const [activeUser, setActiveUser] = useState<{ name: string; email: string; avatar: string } | null>(() => {
    const saved = localStorage.getItem("jansathi_active_user");
    return saved ? JSON.parse(saved) : null;
  });
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [complaints, setComplaints] = useState<any[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [isResponding, setIsResponding] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  
  const [isListening, setIsListening] = useState(false);
  const [speechError, setSpeechError] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);

  // Wake-word Activation States
  const [isWakeWordEnabled, setIsWakeWordEnabled] = useState(false);
  const [wakeWordStatus, setWakeWordStatus] = useState<"idle" | "listening" | "detected">("idle");
  const [showWakeWordToast, setShowWakeWordToast] = useState(false);
  const wakeWordRecRef = useRef<any>(null);

  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);

  const chatEndRef = useRef<HTMLDivElement>(null);
  const t = translations[lang];

  // Stop synthesis on language change or unmount
  useEffect(() => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
    setSpeakingMessageId(null);
  }, [lang]);

  useEffect(() => {
    return () => {
      if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const speakResponse = (text: string, msgId: string) => {
    if (!("speechSynthesis" in window)) {
      alert("Speech synthesis (read aloud) is not supported in this browser. Please try Chrome or Safari.");
      return;
    }

    if (speakingMessageId === msgId) {
      window.speechSynthesis.cancel();
      setSpeakingMessageId(null);
      return;
    }

    window.speechSynthesis.cancel();

    // Clean text of markdown formatting for realistic audio narration
    const cleanText = text
      .replace(/\*\*/g, "")
      .replace(/\*/g, "")
      .replace(/JS-COMP-\d+/g, "Complaint ID $&")
      .replace(/SB-COMP-\d+/g, "Complaint ID $&");

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = lang === "hi" ? "hi-IN" : "en-IN";

    // Set voice match
    const voices = window.speechSynthesis.getVoices();
    let voice = null;
    if (lang === "hi") {
      voice = voices.find(v => v.lang.startsWith("hi"));
    } else {
      voice = voices.find(v => v.lang.startsWith("en-IN") || v.lang.startsWith("en-"));
    }
    if (voice) {
      utterance.voice = voice;
    }

    utterance.onstart = () => {
      setSpeakingMessageId(msgId);
    };

    utterance.onend = () => {
      setSpeakingMessageId(null);
    };

    utterance.onerror = (e) => {
      console.warn("SpeechSynthesis error:", e);
      setSpeakingMessageId(null);
    };

    window.speechSynthesis.speak(utterance);
  };

  // Initialize Speech Recognition
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const rec = new SpeechRecognition();
      rec.continuous = false;
      rec.interimResults = false;
      rec.lang = lang === "hi" ? "hi-IN" : "en-IN";

      rec.onstart = () => {
        setIsListening(true);
        setSpeechError(null);
      };

      rec.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          setInputMessage(prev => {
            const space = prev ? " " : "";
            return prev + space + transcript;
          });
        }
      };

      rec.onerror = (event: any) => {
        console.error("Speech recognition error:", event.error);
        if (event.error === "not-allowed") {
          setSpeechError(lang === "hi" ? "माइक्रोफ़ोन अनुमति अस्वीकृत की गई।" : "Microphone permission denied.");
        } else {
          setSpeechError(event.error);
        }
        setIsListening(false);
      };

      rec.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = rec;
    }
  }, [lang]);

  const toggleListening = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert(t.speechNotSupported);
      return;
    }

    if (!recognitionRef.current) {
      const rec = new SpeechRecognition();
      rec.continuous = false;
      rec.interimResults = false;
      rec.lang = lang === "hi" ? "hi-IN" : "en-IN";
      rec.onstart = () => setIsListening(true);
      rec.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) setInputMessage(prev => prev + (prev ? " " : "") + transcript);
      };
      rec.onerror = () => setIsListening(false);
      rec.onend = () => setIsListening(false);
      recognitionRef.current = rec;
    }

    if (isListening) {
      try {
        recognitionRef.current.stop();
      } catch (e) {
        console.warn(e);
      }
      setIsListening(false);
    } else {
      try {
        recognitionRef.current.start();
      } catch (e) {
        console.error("Failed to start speech recognition:", e);
        setIsListening(false);
      }
    }
  };

  // Web Audio chime for wake word detection
  const playWakeSound = () => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        const ctx = new AudioContextClass();
        
        // Delightful dual-tone futuristic ping
        const osc1 = ctx.createOscillator();
        const gain1 = ctx.createGain();
        osc1.type = "sine";
        osc1.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
        osc1.frequency.exponentialRampToValueAtTime(880.00, ctx.currentTime + 0.12); // A5
        
        gain1.gain.setValueAtTime(0.12, ctx.currentTime);
        gain1.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.25);
        
        osc1.connect(gain1);
        gain1.connect(ctx.destination);
        osc1.start();
        osc1.stop(ctx.currentTime + 0.28);
      }
    } catch (e) {
      console.warn("AudioContext error:", e);
    }
  };

  // Wake-word Activation Service
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      return;
    }

    if (!isWakeWordEnabled) {
      if (wakeWordRecRef.current) {
        try {
          wakeWordRecRef.current.stop();
        } catch (e) {}
        wakeWordRecRef.current = null;
      }
      setWakeWordStatus("idle");
      return;
    }

    // If main voice recorder is active, turn off wake word search temporarily
    if (isListening) {
      if (wakeWordRecRef.current) {
        try {
          wakeWordRecRef.current.stop();
        } catch (e) {}
      }
      return;
    }

    const rec = new SpeechRecognition();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = lang === "hi" ? "hi-IN" : "en-IN";

    rec.onstart = () => {
      setWakeWordStatus("listening");
    };

    rec.onresult = (event: any) => {
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript.toLowerCase();
        
        // Broad search for 'hey jansathi', 'hello jansathi', 'ok jansathi'
        if (
          transcript.includes("hey jansathi") || 
          transcript.includes("hey jan sathi") || 
          transcript.includes("hi jansathi") ||
          transcript.includes("hello jansathi") ||
          transcript.includes("हे जनसाथी") || 
          transcript.includes("है जनसाथी") ||
          transcript.includes("हे जन साथी") ||
          transcript.includes("है जन साथी")
        ) {
          setWakeWordStatus("detected");
          playWakeSound();
          
          // Show wake word toast temporarily
          setShowWakeWordToast(true);
          setTimeout(() => {
            setShowWakeWordToast(false);
          }, 3500);

          try {
            rec.stop();
          } catch (e) {}

          // Automatically trigger active voice query capture
          setTimeout(() => {
            if (!isListening) {
              toggleListening();
            }
          }, 200);
          break;
        }
      }
    };

    rec.onerror = (err: any) => {
      console.warn("Wake-word listener error:", err.error);
    };

    rec.onend = () => {
      // Auto restart if still enabled, not listening to query, and not just triggered
      if (isWakeWordEnabled && !isListening && wakeWordStatus !== "detected") {
        try {
          rec.start();
        } catch (e) {
          console.warn("Failed to restart wake-word listener:", e);
        }
      }
    };

    wakeWordRecRef.current = rec;

    try {
      rec.start();
    } catch (e) {
      console.warn("Failed to start wake-word service:", e);
    }

    return () => {
      if (wakeWordRecRef.current) {
        try {
          wakeWordRecRef.current.stop();
        } catch (e) {}
        wakeWordRecRef.current = null;
      }
    };
  }, [isWakeWordEnabled, isListening, lang]);

  // Initialize with a welcome message on load
  useEffect(() => {
    if (messages.length === 0) {
      const welcome = activeUser
        ? (lang === "hi" ? `नमस्ते, ${activeUser.name}! मैं आपका जनसाथी एआई नागरिक साथी हूं।` : `Namaste, ${activeUser.name}! I am your JanSathi AI Civic Companion.`)
        : t.welcomeTitle;
      setMessages([
        {
          id: "welcome-msg",
          role: "model",
          text: `${welcome}\n\n${t.welcomeSubtitle}\n\n*Please verify details on the official government portal.*`,
          timestamp: new Date(),
        }
      ]);
    }
  }, [lang, activeUser]);

  const handleMessageFeedback = (msgId: string, feedbackType: "like" | "dislike") => {
    setMessages(prev =>
      prev.map(msg => {
        if (msg.id === msgId) {
          const newFeedback = msg.feedback === feedbackType ? null : feedbackType;
          return { ...msg, feedback: newFeedback };
        }
        return msg;
      })
    );
  };

  // Auto-scroll chat to bottom
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isResponding]);

  const handleSendMessage = async (customText?: string) => {
    const textToSend = customText !== undefined ? customText : inputMessage.trim();
    if (!textToSend) return;

    if (customText === undefined) {
      setInputMessage("");
    }
    
    setErrorMessage(null);

    // Create user message object
    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}-user`,
      role: "user",
      text: textToSend,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setIsResponding(true);

    try {
      // Keep only last 10 messages for context to optimize speed
      const chatHistory = messages
        .filter(m => m.id !== "welcome-msg")
        .slice(-10)
        .map(m => ({
          role: m.role,
          text: m.text
        }));

      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          message: textToSend,
          history: chatHistory
        })
      });

      if (!response.ok) {
        throw new Error("Server error while retrieving assistance");
      }

      const data = await response.json();

      // Create model message object with structured keys
      const modelMsg: ChatMessage = {
        id: `msg-${Date.now()}-model`,
        role: "model",
        text: data.replyText,
        intent: data.intent,
        complaintData: data.complaintData,
        documentHelpData: data.documentHelpData,
        schemeFinderData: data.schemeFinderData,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, modelMsg]);

      // If intent is COMPLAINT and it is "Ready" with ID, add to list of complaints
      if (data.intent === "COMPLAINT" && data.complaintData) {
        const c = data.complaintData;
        if (c.status === "Ready" && c.complaintId) {
          setComplaints(prev => {
            if (prev.some(comp => comp.complaintId === c.complaintId)) return prev;
            return [
              {
                complaintId: c.complaintId,
                category: c.category,
                location: c.location,
                description: c.description,
                urgency: c.urgency,
                status: c.status,
                timestamp: new Date()
              },
              ...prev
            ];
          });
        }
      }

    } catch (err: any) {
      console.error(err);
      setErrorMessage(t.apiError);
    } finally {
      setIsResponding(false);
    }
  };

  // Preset suggestions helper
  const handleSuggestionClick = (query: string) => {
    handleSendMessage(query);
  };

  const handleClearChat = () => {
    setMessages([
      {
        id: `welcome-msg-${Date.now()}`,
        role: "model",
        text: `${t.welcomeTitle}\n\n${t.welcomeSubtitle}\n\n*Please verify details on the official government portal.*`,
        timestamp: new Date(),
      }
    ]);
    setErrorMessage(null);
  };

  const addTestComplaint = (testComplaint: any) => {
    setComplaints(prev => {
      if (prev.some(comp => comp.complaintId === testComplaint.complaintId)) return prev;
      return [testComplaint, ...prev];
    });
  };

  if (!activeUser) {
    return (
      <AuthScreen 
        lang={lang} 
        onLangChange={(newLang) => setLang(newLang)}
        onLoginSuccess={(user) => {
          setActiveUser(user);
          localStorage.setItem("jansathi_active_user", JSON.stringify(user));
        }} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#030712] text-slate-100 flex flex-col font-sans antialiased bg-[radial-gradient(#1f2937_1px,transparent_1px)] [background-size:16px_16px] relative" id="smart-bharat-root">
      {/* WAVE LIKE TRICOLOR MOVING BACKGROUND AT THE TOP OF ALL DASHBOARD PAGES */}
      <MovingTricolorWave position="top" opacity={0.15} height={130} />

      {/* TRICOLOR TOP BAR - Sleek glowing accent */}
      <div className="h-1 bg-gradient-to-r from-amber-500 via-zinc-100 to-emerald-500 shadow-lg shadow-emerald-500/20 z-10" />

      {/* HEADER SECTION */}
      <header className="bg-slate-900/80 backdrop-blur-md border-b border-slate-800/80 sticky top-0 z-40 shadow-xl shadow-black/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 sm:py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Automated Animated 3D-feeling Robot Branding */}
            <AnimatedRobotLogo 
              isListening={isListening} 
              isResponding={isResponding} 
              isSpeaking={speakingMessageId !== null} 
            />
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-lg sm:text-xl font-extrabold text-white tracking-tight flex items-center gap-1">
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-white to-emerald-400">
                    {t.title}
                  </span>
                </h1>
                <span className="text-[10px] sm:text-xs font-bold uppercase tracking-widest bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 px-1.5 py-0.5 rounded">
                  GenAI
                </span>
              </div>
              <p className="text-[10px] sm:text-xs text-slate-400 font-medium">
                {t.subtitle}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Clear conversation helper */}
            <button
              onClick={handleClearChat}
              className="p-2 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              title={t.newChat}
              aria-label="Clear chat"
            >
              <RotateCcw size={18} />
            </button>

            {/* Language Selection Toggle */}
            <button
              onClick={() => setLang(prev => prev === "en" ? "hi" : "en")}
              className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer border border-slate-700"
              aria-label="Toggle language"
            >
              <Languages size={14} className="text-indigo-400" />
              <span>{t.languageToggle}</span>
            </button>

            {/* Active User profile details & Logout */}
            {activeUser && (
              <div className="flex items-center gap-2 border-l border-slate-800 pl-2 shrink-0">
                <div className="flex items-center gap-1.5 bg-slate-800/80 border border-slate-700/60 px-2 sm:px-2.5 py-1.5 rounded-xl">
                  <span className="text-sm select-none" role="img" aria-label="avatar">
                    {activeUser.avatar}
                  </span>
                  <div className="hidden sm:flex flex-col text-left">
                    <span className="text-[10px] font-bold text-slate-200 leading-none truncate max-w-[80px]">
                      {activeUser.name}
                    </span>
                    <span className="text-[8px] text-slate-500 font-medium leading-none mt-0.5 truncate max-w-[80px]">
                      {activeUser.email}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setActiveUser(null);
                    localStorage.removeItem("jansathi_active_user");
                    setMessages([]);
                  }}
                  className="p-2 bg-slate-800 hover:bg-rose-950/40 border border-slate-700 hover:border-rose-900/30 text-slate-400 hover:text-rose-400 rounded-xl transition-all cursor-pointer"
                  title={lang === "hi" ? "लॉग आउट करें" : "Logout"}
                  aria-label="Logout"
                >
                  <LogOut size={14} />
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* MAIN CONTAINER */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col md:flex-row gap-6">
        
        {/* RESPONSIVE NAVIGATION TABS / SIDEBAR */}
        <section className="w-full md:w-64 flex flex-row md:flex-col overflow-x-auto md:overflow-x-visible border-b md:border-b-0 md:border-r border-slate-800/80 pb-3 md:pb-0 md:pr-6 gap-1 shrink-0 scrollbar-none">
          <button
            onClick={() => setActiveTab("chat")}
            className={`flex items-center gap-2.5 px-4 py-2.5 rounded-lg text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === "chat"
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/15"
                : "text-slate-400 hover:bg-slate-900/60 hover:text-slate-200"
            }`}
          >
            <Bot size={16} />
            <span>{t.tabChat}</span>
          </button>

          <button
            onClick={() => setActiveTab("complaints")}
            className={`flex items-center justify-between gap-2 px-4 py-2.5 rounded-lg text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === "complaints"
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/15"
                : "text-slate-400 hover:bg-slate-900/60 hover:text-slate-200"
            }`}
          >
            <div className="flex items-center gap-2.5">
              <AlertTriangle size={16} />
              <span>{t.tabComplaints}</span>
            </div>
            {complaints.length > 0 && (
              <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${activeTab === "complaints" ? "bg-white text-indigo-600" : "bg-red-500/20 text-red-400 border border-red-500/30"}`}>
                {complaints.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab("schemes")}
            className={`flex items-center gap-2.5 px-4 py-2.5 rounded-lg text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === "schemes"
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/15"
                : "text-slate-400 hover:bg-slate-900/60 hover:text-slate-200"
            }`}
          >
            <Award size={16} />
            <span>{t.tabSchemes}</span>
          </button>

          <button
            onClick={() => setActiveTab("documents")}
            className={`flex items-center gap-2.5 px-4 py-2.5 rounded-lg text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === "documents"
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/15"
                : "text-slate-400 hover:bg-slate-900/60 hover:text-slate-200"
            }`}
          >
            <FileText size={16} />
            <span>{t.tabDocuments}</span>
          </button>

          <button
            onClick={() => setActiveTab("faqs")}
            className={`flex items-center gap-2.5 px-4 py-2.5 rounded-lg text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === "faqs"
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/15"
                : "text-slate-400 hover:bg-slate-900/60 hover:text-slate-200"
            }`}
          >
            <HelpCircle size={16} />
            <span>{t.tabFaqs}</span>
          </button>

          <div className="hidden md:block my-4 border-t border-slate-800" />

          <button
            onClick={() => setActiveTab("tests")}
            className={`flex items-center gap-2.5 px-4 py-2.5 rounded-lg text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === "tests"
                ? "bg-emerald-600 text-white shadow-lg shadow-emerald-600/15"
                : "text-emerald-400 hover:bg-emerald-950/40 border border-emerald-500/20"
            }`}
          >
            <Sparkles size={16} />
            <span>{t.testHeader}</span>
          </button>
        </section>

        {/* ACTIVE SECTION RENDERER */}
        <section className="flex-1 flex flex-col min-w-0">
          <AnimatePresence mode="wait">
            
            {/* CHAT INTERFACE TAB */}
            {activeTab === "chat" && (
              <motion.div
                key="chat-tab"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.15 }}
                className="flex-1 flex flex-col min-w-0"
              >
                {/* 3D Welcoming Avatar */}
                <WelcomeAvatar3D lang={lang} userName={activeUser?.name} />

                <div className="flex-1 flex flex-col bg-slate-950/40 border border-slate-800/80 rounded-2xl shadow-2xl backdrop-blur-sm overflow-hidden min-h-[500px] relative">
                {/* Chat window viewport */}
                <div className="flex-1 p-4 overflow-y-auto space-y-4 max-h-[500px] min-h-[300px] scrollbar-thin">
                  {messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex gap-3 max-w-[85%] ${
                        msg.role === "user" ? "ml-auto flex-row-reverse" : ""
                      }`}
                    >
                      {/* Avatar */}
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 border ${
                        msg.role === "user" 
                          ? "bg-indigo-950/50 text-indigo-400 border-indigo-500/20" 
                          : "bg-slate-900 text-indigo-400 border-slate-700/50"
                      }`}>
                        {msg.role === "user" ? <User size={15} /> : <Bot size={15} />}
                      </div>

                      {/* Bubble content */}
                      <div className="space-y-3 group/bubble max-w-full">
                        <div className={`rounded-2xl p-3.5 leading-relaxed text-sm ${
                          msg.role === "user"
                            ? "bg-indigo-600 text-white rounded-tr-none shadow-md shadow-indigo-600/10 border border-indigo-500/20"
                            : "bg-slate-900 text-slate-100 rounded-tl-none border border-slate-800/80 shadow-md shadow-black/20"
                        }`}>
                          <p className="whitespace-pre-wrap">{msg.text}</p>
                          
                          {msg.role === "model" && msg.intent && (
                            <div className="mt-2.5 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                              <span className="inline-block w-1.5 h-1.5 rounded-full bg-indigo-400" />
                              {msg.intent === "GENERAL_QUERY" && t.generalQuery}
                              {msg.intent === "COMPLAINT" && t.complaintLogged}
                              {msg.intent === "DOCUMENT_HELP" && t.docHelp}
                              {msg.intent === "SCHEME_FINDER" && t.schemeFinder}
                            </div>
                          )}
                        </div>

                        {/* Interactive Text to Speech Player & Feedback Controls */}
                        {msg.role === "model" && (
                          <div className="flex items-center gap-2 mt-1 opacity-80 group-hover/bubble:opacity-100 transition-opacity">
                            <button
                              onClick={() => speakResponse(msg.text, msg.id)}
                              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium border transition-all cursor-pointer active:scale-95 ${
                                speakingMessageId === msg.id
                                  ? "bg-rose-500/10 text-rose-400 border-rose-500/30 animate-pulse"
                                  : "bg-slate-800/40 text-slate-300 border-slate-700/50 hover:bg-slate-800"
                              }`}
                              title={speakingMessageId === msg.id ? t.ttsStop : t.ttsRead}
                              aria-label={speakingMessageId === msg.id ? t.ttsStop : t.ttsRead}
                            >
                              {speakingMessageId === msg.id ? (
                                <>
                                  <VolumeX size={12} className="text-rose-400 shrink-0" />
                                  <span>{t.ttsStop}</span>
                                </>
                              ) : (
                                <>
                                  <Volume2 size={12} className="text-indigo-400 shrink-0 animate-pulse" />
                                  <span>{t.ttsRead}</span>
                                </>
                              )}
                            </button>

                            <span className="w-[1px] h-3.5 bg-slate-800/80 mx-0.5" />

                            {/* Thumbs Up Button */}
                            <button
                              onClick={() => handleMessageFeedback(msg.id, "like")}
                              className={`p-1.5 rounded-full border transition-all cursor-pointer active:scale-90 flex items-center justify-center ${
                                msg.feedback === "like"
                                  ? "bg-emerald-500/15 border-emerald-500/30 text-emerald-400"
                                  : "bg-slate-800/20 border-slate-700/40 text-slate-400 hover:text-slate-200"
                              }`}
                              title={lang === "hi" ? "पसंद करें" : "Thumbs Up"}
                              aria-label="Thumbs Up"
                            >
                              <ThumbsUp size={11} className={msg.feedback === "like" ? "fill-emerald-400" : ""} />
                            </button>

                            {/* Thumbs Down Button */}
                            <button
                              onClick={() => handleMessageFeedback(msg.id, "dislike")}
                              className={`p-1.5 rounded-full border transition-all cursor-pointer active:scale-90 flex items-center justify-center ${
                                msg.feedback === "dislike"
                                  ? "bg-rose-500/15 border-rose-500/30 text-rose-400"
                                  : "bg-slate-800/20 border-slate-700/40 text-slate-400 hover:text-rose-400"
                              }`}
                              title={lang === "hi" ? "नापसंद करें" : "Thumbs Down"}
                              aria-label="Thumbs Down"
                            >
                              <ThumbsDown size={11} className={msg.feedback === "dislike" ? "fill-rose-400" : ""} />
                            </button>

                            {/* Feedback thank you tooltip */}
                            {msg.feedback && (
                              <motion.span 
                                initial={{ opacity: 0, x: -5 }}
                                animate={{ opacity: 1, x: 0 }}
                                className="text-[9px] text-slate-500 font-bold tracking-wide"
                              >
                                {lang === "hi" ? "धन्यवाद!" : "Thanks!"}
                              </motion.span>
                            )}
                          </div>
                        )}

                        {/* Embedded Structured Cards within Chat flow */}
                        {msg.role === "model" && msg.intent === "COMPLAINT" && msg.complaintData && (
                          <motion.div
                            initial={{ scale: 0.95, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            className="max-w-xl"
                          >
                            <ComplaintCard data={msg.complaintData} date={msg.timestamp} />
                          </motion.div>
                        )}

                        {msg.role === "model" && msg.intent === "DOCUMENT_HELP" && msg.documentHelpData && (
                          <motion.div
                            initial={{ scale: 0.95, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            className="max-w-xl"
                          >
                            <DocumentChecklist data={msg.documentHelpData} lang={lang} />
                          </motion.div>
                        )}

                        {msg.role === "model" && msg.intent === "SCHEME_FINDER" && msg.schemeFinderData && msg.schemeFinderData.recommendedSchemes && (
                          <motion.div
                            initial={{ scale: 0.95, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            className="max-w-xl"
                          >
                            <SchemeCard schemes={msg.schemeFinderData.recommendedSchemes} />
                          </motion.div>
                        )}
                      </div>
                    </div>
                  ))}

                  {isResponding && (
                    <div className="flex gap-3 max-w-[85%]">
                      <div className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 text-indigo-400 flex items-center justify-center shrink-0">
                        <Bot size={15} />
                      </div>
                      <div className="bg-slate-900 border border-slate-800 rounded-2xl rounded-tl-none p-4 text-xs text-slate-400 flex items-center gap-2.5">
                        <Loader2 className="animate-spin text-indigo-400" size={14} />
                        <span>{t.title} Companion is thinking...</span>
                      </div>
                    </div>
                  )}

                  {errorMessage && (
                    <div className="bg-rose-950/40 border border-rose-500/20 rounded-xl p-4 text-rose-300 text-xs flex gap-2">
                      <AlertTriangle size={16} className="text-rose-400 shrink-0" />
                      <div>
                        <p className="font-semibold">{errorMessage}</p>
                        <button 
                          onClick={() => handleSendMessage()} 
                          className="mt-2 text-rose-400 underline font-semibold hover:text-rose-300 cursor-pointer"
                        >
                          Retry last message
                        </button>
                      </div>
                    </div>
                  )}

                  <div ref={chatEndRef} />
                </div>

                {/* SUGGESTION PILLS (Helps first-time users query) */}
                {messages.length <= 1 && !isResponding && (
                  <div className="px-4 py-3 bg-slate-900/40 border-t border-slate-800/80">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-2">
                      Popular Citizen Queries:
                    </span>
                    <div className="flex flex-wrap gap-2">
                      <button
                        onClick={() => handleSuggestionClick("How can I apply for fresh Voter ID card? What are the documents needed?")}
                        className="text-xs bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded-full px-3.5 py-1.5 transition-all text-left max-w-full truncate shadow-xs cursor-pointer"
                      >
                        Voter ID Process 📋
                      </button>
                      <button
                        onClick={() => handleSuggestionClick("I am a 48 year old female handloom weaver in Andhra Pradesh. Family income is 1.2 lakhs. What government schemes qualify for me?")}
                        className="text-xs bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded-full px-3.5 py-1.5 transition-all text-left max-w-full truncate shadow-xs cursor-pointer"
                      >
                        Scheme Finder 🌾
                      </button>
                      <button
                        onClick={() => handleSuggestionClick("Report severe water leakage and garbage pile at Gandhi Nagar Market, Block C, Delhi. It is blocking roads and causing terrible odor.")}
                        className="text-xs bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded-full px-3.5 py-1.5 transition-all text-left max-w-full truncate shadow-xs cursor-pointer"
                      >
                        Report Water Leakage 💧
                      </button>
                    </div>
                  </div>
                )}

                {/* Input box bottom panel */}
                <div className="p-3 border-t border-slate-800/80 bg-slate-900/60">
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      handleSendMessage();
                    }}
                    className="flex gap-2 items-center"
                  >
                    <input
                      type="text"
                      value={inputMessage}
                      onChange={(e) => setInputMessage(e.target.value)}
                      placeholder={isListening ? t.listening : t.placeholder}
                      disabled={isResponding}
                      className={`flex-1 bg-slate-950 text-slate-100 placeholder-slate-500 text-sm px-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/25 focus:bg-slate-950 border border-slate-800 transition-all disabled:opacity-50 ${isListening ? "border-rose-500 ring-2 ring-rose-500/25 bg-rose-950/20" : ""}`}
                      aria-label="Civic query input"
                    />

                    {/* Voice Input Button */}
                    <button
                      type="button"
                      onClick={toggleListening}
                      disabled={isResponding}
                      className={`p-3 rounded-xl transition-all active:scale-95 shrink-0 cursor-pointer relative ${
                        isListening 
                          ? "bg-rose-600 text-white animate-pulse" 
                          : "bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white"
                      }`}
                      title={isListening ? t.stopVoice : t.startVoice}
                      aria-label={isListening ? t.stopVoice : t.startVoice}
                    >
                      {isListening ? (
                        <>
                          <MicOff size={18} />
                          <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
                          </span>
                        </>
                      ) : (
                        <Mic size={18} />
                      )}
                    </button>

                    {/* Wake Word Activation Toggle */}
                    <button
                      type="button"
                      onClick={() => setIsWakeWordEnabled(prev => !prev)}
                      disabled={isResponding}
                      className={`p-3 rounded-xl transition-all active:scale-95 shrink-0 cursor-pointer relative border ${
                        isWakeWordEnabled 
                          ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30 shadow-inner shadow-emerald-500/20" 
                          : "bg-slate-800 text-slate-400 border-slate-700/50 hover:bg-slate-700 hover:text-slate-300"
                      }`}
                      title={t.wakeWordTitle}
                      aria-label={t.wakeWordTitle}
                    >
                      {isWakeWordEnabled ? (
                        <>
                          <Radio size={18} className="animate-pulse" />
                          <span className="absolute -top-1 -right-1 flex h-2 w-2">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                          </span>
                        </>
                      ) : (
                        <Ear size={18} />
                      )}
                    </button>

                    <button
                      type="submit"
                      disabled={!inputMessage.trim() || isResponding || isListening}
                      className="bg-indigo-600 hover:bg-indigo-500 text-white p-3 rounded-xl transition-all disabled:opacity-40 disabled:scale-100 active:scale-95 shrink-0 cursor-pointer shadow-md shadow-indigo-600/10"
                      aria-label="Send message"
                    >
                      <Send size={18} />
                    </button>
                  </form>

                  {isListening && (
                    <div className="flex items-center gap-1.5 justify-center mt-2.5 text-xs text-rose-400 font-semibold animate-pulse">
                      <span className="w-2 h-2 bg-rose-500 rounded-full animate-ping" />
                      <span>{t.listening}</span>
                    </div>
                  )}

                  {isWakeWordEnabled && !isListening && (
                    <div className="flex items-center gap-1.5 justify-center mt-2.5 text-[11px] text-emerald-400/90 font-medium animate-pulse">
                      <Radio size={12} className="text-emerald-400 shrink-0" />
                      <span>{t.wakeWordListening}</span>
                    </div>
                  )}

                  {speechError && (
                    <div className="mt-2 text-center text-[11px] text-rose-400 font-medium bg-rose-950/40 py-1 px-3 rounded-md border border-rose-500/20 max-w-xs mx-auto">
                      {speechError}
                    </div>
                  )}
                  <p className="text-[10px] text-slate-500 mt-2 text-center font-medium leading-relaxed">
                    {t.disclaimer}
                  </p>

                  {/* Wake Word Detected Beautiful floating banner */}
                  <AnimatePresence>
                    {showWakeWordToast && (
                      <motion.div
                        initial={{ opacity: 0, y: 15, x: "-50%" }}
                        animate={{ opacity: 1, y: 0, x: "-50%" }}
                        exit={{ opacity: 0, y: -10, x: "-50%" }}
                        className="absolute bottom-28 left-1/2 transform -translate-x-1/2 z-50 bg-slate-950/95 border border-emerald-500/40 shadow-2xl shadow-emerald-500/20 px-4 py-2.5 rounded-2xl flex items-center gap-3 backdrop-blur-md w-[90%] max-w-xs"
                      >
                        <div className="w-8 h-8 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shrink-0">
                          <Radio size={16} className="animate-pulse" />
                        </div>
                        <div className="text-left">
                          <h4 className="text-[10px] font-black uppercase tracking-wider text-[#FF9933]">JanSathi Active!</h4>
                          <p className="text-xs text-slate-200 leading-tight mt-0.5">{t.wakeWordDetected}</p>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </motion.div>
            )}

            {/* MY COMPLAINTS LIST TAB */}
            {activeTab === "complaints" && (
              <motion.div
                key="complaints-tab"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.15 }}
                className="space-y-4"
              >
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                    <AlertTriangle size={20} className="text-[#FF9933]" />
                    {t.tabComplaints} ({complaints.length})
                  </h2>
                  
                  {complaints.length > 0 && (
                    <button
                      onClick={() => setComplaints([])}
                      className="flex items-center gap-1 text-xs text-rose-400 hover:text-rose-300 font-bold transition-all cursor-pointer bg-rose-950/20 border border-rose-500/20 rounded-lg px-2.5 py-1"
                    >
                      <Trash2 size={13} />
                      Clear Session Complaints
                    </button>
                  )}
                </div>

                {complaints.length === 0 ? (
                  <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-8 text-center max-w-xl mx-auto space-y-4 shadow-xl">
                    <div className="w-14 h-14 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto text-[#FF9933]">
                      <AlertTriangle size={28} />
                    </div>
                    <p className="text-sm text-slate-400 leading-relaxed font-medium">
                      {t.noComplaints}
                    </p>
                    <button
                      onClick={() => setActiveTab("chat")}
                      className="inline-flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs px-4 py-2 rounded-lg cursor-pointer transition-all"
                    >
                      <span>Go to Chat</span>
                      <ArrowRight size={14} />
                    </button>
                  </div>
                ) : (
                  <div className="grid gap-4 md:grid-cols-2">
                    {complaints.map((comp) => (
                      <ComplaintCard key={comp.complaintId} data={comp} date={comp.timestamp} />
                    ))}
                  </div>
                )}
              </motion.div>
            )}

            {/* SCHEME FINDER HISTORY TAB */}
            {activeTab === "schemes" && (
              <motion.div
                key="schemes-tab"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.15 }}
                className="space-y-4"
              >
                <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                  <Award size={20} className="text-[#FF9933]" />
                  {t.tabSchemes}
                </h2>

                {/* Filter and display scheme matches from current session chat history */}
                {messages.filter(m => m.role === "model" && m.intent === "SCHEME_FINDER" && m.schemeFinderData?.recommendedSchemes).length === 0 ? (
                  <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-8 text-center max-w-xl mx-auto space-y-4 shadow-xl">
                    <div className="w-14 h-14 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto text-[#FF9933]">
                      <Award size={28} />
                    </div>
                    <p className="text-sm text-slate-400 leading-relaxed font-medium">
                      {t.noSchemes}
                    </p>
                    <button
                      onClick={() => {
                        setActiveTab("chat");
                        handleSuggestionClick("I am a 48 year old female handloom weaver in Andhra Pradesh. Family income is 1.2 lakhs. What government schemes qualify for me?");
                      }}
                      className="inline-flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs px-4 py-2 rounded-lg cursor-pointer transition-all"
                    >
                      <span>Explore Schemes</span>
                      <ArrowRight size={14} />
                    </button>
                  </div>
                ) : (
                  <div className="space-y-6 max-w-3xl">
                    {messages
                      .filter(m => m.role === "model" && m.intent === "SCHEME_FINDER" && m.schemeFinderData?.recommendedSchemes)
                      .map((msg, index) => (
                        <div key={index} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
                          <span className="text-[10px] font-bold text-[#FF9933] uppercase tracking-widest block border-b border-slate-800 pb-2">
                            Search Result #{index + 1} ({new Date(msg.timestamp).toLocaleDateString()})
                          </span>
                          <p className="text-xs text-slate-400 bg-slate-950 p-3 rounded-lg leading-relaxed border border-slate-800">
                            "{msg.text.split("\n\n*")[0]}"
                          </p>
                          <SchemeCard schemes={msg.schemeFinderData!.recommendedSchemes!} />
                        </div>
                      ))}
                  </div>
                )}
              </motion.div>
            )}

            {/* DOCUMENT CHECKLIST HISTORY TAB */}
            {activeTab === "documents" && (
              <motion.div
                key="documents-tab"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.15 }}
                className="space-y-4"
              >
                <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                  <FileText size={20} className="text-indigo-400" />
                  {t.tabDocuments}
                </h2>

                {/* Filter and display document checklists from chat history */}
                {messages.filter(m => m.role === "model" && m.intent === "DOCUMENT_HELP" && m.documentHelpData).length === 0 ? (
                  <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-8 text-center max-w-xl mx-auto space-y-4 shadow-xl">
                    <div className="w-14 h-14 bg-indigo-500/10 rounded-full flex items-center justify-center mx-auto text-indigo-400">
                      <FileText size={28} />
                    </div>
                    <p className="text-sm text-slate-400 leading-relaxed font-medium">
                      {t.noDocuments}
                    </p>
                    <button
                      onClick={() => {
                        setActiveTab("chat");
                        handleSuggestionClick("How can I apply for fresh Voter ID card? What are the documents needed?");
                      }}
                      className="inline-flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs px-4 py-2 rounded-lg cursor-pointer transition-all"
                    >
                      <span>Search Documents</span>
                      <ArrowRight size={14} />
                    </button>
                  </div>
                ) : (
                  <div className="space-y-6 max-w-3xl">
                    {messages
                      .filter(m => m.role === "model" && m.intent === "DOCUMENT_HELP" && m.documentHelpData)
                      .map((msg, index) => (
                        <div key={index} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
                          <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest block border-b border-slate-800 pb-2">
                            Checklist #{index + 1} ({new Date(msg.timestamp).toLocaleDateString()})
                          </span>
                          <p className="text-xs text-slate-400 bg-slate-950 p-3 rounded-lg leading-relaxed border border-slate-800">
                            "{msg.text.split("\n\n*")[0]}"
                          </p>
                          <DocumentChecklist data={msg.documentHelpData!} lang={lang} />
                        </div>
                      ))}
                  </div>
                )}
              </motion.div>
            )}

            {/* FAQS & GOVERNMENT PROCESSES TAB */}
            {activeTab === "faqs" && (
              <motion.div
                key="faqs-tab"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.15 }}
                className="w-full flex-1"
              >
                <FaqTab lang={lang} />
              </motion.div>
            )}

            {/* DEVELOPER TESTING & VALIDATION SUITE TAB */}
            {activeTab === "tests" && (
              <motion.div
                key="tests-tab"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.15 }}
                className="space-y-4 max-w-4xl"
              >
                <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
                  <h2 className="text-xl font-extrabold text-slate-100 mb-2 flex items-center gap-2">
                    <Sparkles className="text-amber-400 animate-pulse" size={24} />
                    {t.testIntro.split(". ")[0]}.
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-400 leading-relaxed mb-6 border-b border-slate-800 pb-4">
                    {t.testIntro}
                  </p>
                  
                  <ValidationSuite onAddTestComplaints={addTestComplaint} />
                </div>
              </motion.div>
            )}

          </AnimatePresence>
        </section>

      </main>

      {/* PERSISTENT FOOTER */}
      <footer className="relative bg-slate-950 border-t border-slate-800/80 py-8 text-xs text-slate-500 mt-12 overflow-hidden">
        {/* WAVE LIKE TRICOLOR MOVING BACKGROUND IN THE DASHBOARD FOOTER */}
        <MovingTricolorWave opacity={0.15} height={110} />

        <div className="relative z-10 max-w-7xl mx-auto px-4 text-center space-y-2">
          <p className="font-semibold text-slate-300">
            JanSathi — Har Nagrik Ka Digital Saathi
          </p>
          <p className="max-w-xl mx-auto leading-relaxed text-slate-400">
            Designed with a creative, modern, dark civic-tech aesthetic. Encourages transparent public engagement and direct service discovery for all Indian citizens.
          </p>
          <div className="flex items-center justify-center gap-2 pt-2">
            <span className="w-3 h-3 bg-amber-500 rounded-full shadow-lg shadow-amber-500/20" />
            <span className="w-3 h-3 bg-zinc-200 border border-slate-700 rounded-full" />
            <span className="w-3 h-3 bg-emerald-500 rounded-full shadow-lg shadow-emerald-500/20" />
          </div>
        </div>
      </footer>
    </div>
  );
}
