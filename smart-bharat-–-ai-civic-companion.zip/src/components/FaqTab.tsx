import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Search, 
  ChevronDown, 
  ExternalLink, 
  HelpCircle, 
  Globe, 
  Bookmark, 
  FileCheck,
  UserCheck,
  Megaphone,
  Sparkles
} from "lucide-react";

interface FAQItem {
  id: string;
  category: "identity" | "voter" | "civic" | "schemes";
  question: { en: string; hi: string };
  answer: { en: string; hi: string };
  steps?: { en: string[]; hi: string[] };
}

interface QuickLink {
  name: { en: string; hi: string };
  desc: { en: string; hi: string };
  url: string;
  icon: React.ReactNode;
}

interface FaqTabProps {
  lang: "en" | "hi";
}

export const FaqTab: React.FC<FaqTabProps> = ({ lang }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<"all" | "identity" | "voter" | "civic" | "schemes">("all");
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const categories = {
    all: { en: "All Topics", hi: "सभी विषय" },
    identity: { en: "Aadhaar & Identity", hi: "आधार और पहचान" },
    voter: { en: "Voter Services", hi: "मतदाता सेवाएं" },
    civic: { en: "Civic & Municipal", hi: "नागरिक और नगर निगम" },
    schemes: { en: "Government Schemes", hi: "सरकारी योजनाएं" }
  };

  const faqData: FAQItem[] = [
    {
      id: "faq-1",
      category: "identity",
      question: {
        en: "How do I link my Aadhaar card with my current mobile number?",
        hi: "मैं अपने आधार कार्ड को अपने वर्तमान मोबाइल नंबर से कैसे लिंक करूँ?"
      },
      answer: {
        en: "For security reasons, linking a mobile number to Aadhaar cannot be done completely online. You must visit a physical Aadhaar Enrolment Centre.",
        hi: "सुरक्षा कारणों से, आधार से मोबाइल नंबर लिंक करने का काम पूरी तरह से ऑनलाइन नहीं किया जा सकता है। आपको किसी नजदीकी आधार नामांकन केंद्र पर जाना होगा।"
      },
      steps: {
        en: [
          "Locate your nearest authorized Aadhaar Seva Kendra.",
          "Fill out the Aadhaar Update/Correction Form.",
          "Submit the form and provide your biometric verification (thumbprint/iris scan).",
          "Pay the nominal update fee of ₹50. The update usually takes 2 to 5 working days."
        ],
        hi: [
          "अपने निकटतम अधिकृत आधार सेवा केंद्र का पता लगाएं।",
          "आधार अपडेट/संशोधन फॉर्म भरें।",
          "फॉर्म जमा करें और अपना बायोमेट्रिक सत्यापन (अंगूठे का निशान/आईरिस स्कैन) प्रदान करें।",
          "₹50 का मामूली अपडेट शुल्क भुगतान करें। अपडेट होने में आमतौर पर 2 से 5 कार्य दिवस लगते हैं।"
        ]
      }
    },
    {
      id: "faq-2",
      category: "voter",
      question: {
        en: "My name is missing from the Voter List. How do I register to vote?",
        hi: "मेरा नाम मतदाता सूची में नहीं है। मैं वोट देने के लिए पंजीकरण कैसे करूँ?"
      },
      answer: {
        en: "If your name is missing or you have recently turned 18, you can easily register online through the National Voters Service Portal (NVSP) by submitting Form 6.",
        hi: "यदि आपका नाम गायब है या आप हाल ही में 18 वर्ष के हुए हैं, तो आप फॉर्म 6 भरकर राष्ट्रीय मतदाता सेवा पोर्टल (NVSP) के माध्यम से आसानी से ऑनलाइन पंजीकरण कर सकते हैं।"
      },
      steps: {
        en: [
          "Visit the official voters portal (voters.eci.gov.in).",
          "Sign up/Login to the portal and select 'Form 6' (Register as a New Elector).",
          "Upload a passport-size photo, age proof (e.g. Birth certificate, PAN), and address proof.",
          "Submit the application. A Booth Level Officer (BLO) will visit your address for verification."
        ],
        hi: [
          "आधिकारिक मतदाता पोर्टल (voters.eci.gov.in) पर जाएं।",
          "पोर्टल पर साइन अप/लॉगिन करें और 'फॉर्म 6' (नए मतदाता के रूप में पंजीकरण) चुनें।",
          "पासपोर्ट साइज फोटो, आयु प्रमाण पत्र (जैसे जन्म प्रमाण पत्र, पैन) और पता प्रमाण अपलोड करें।",
          "आवेदन जमा करें। सत्यापन के लिए एक बूथ स्तर के अधिकारी (BLO) आपके पते पर आएंगे।"
        ]
      }
    },
    {
      id: "faq-3",
      category: "civic",
      question: {
        en: "What is the official resolution timeline for public garbage and water leakage complaints?",
        hi: "सार्वजनिक कचरा और पानी के रिसाव की शिकायतों के समाधान की आधिकारिक समय सीमा क्या है?"
      },
      answer: {
        en: "Under Citizen Charters of most Municipal Corporations in India, civic grievances have priority-based timelines. Simple waste clearance is resolved rapidly.",
        hi: "भारत में अधिकांश नगर निगमों के नागरिक चार्टर के तहत, नागरिक शिकायतों के समाधान की समय सीमा प्राथमिकता पर आधारित होती है। कचरा हटाने का काम बहुत जल्दी होता है।"
      },
      steps: {
        en: [
          "Garbage Pile Clearing: Typically 24 to 48 hours from successful registration.",
          "Water Pipe Leakage (Minor): 24 hours. Major pipeline bursts may take 3 to 5 days.",
          "Streetlight Failure: Usually 48 hours to 3 working days depending on bulb/wiring issues.",
          "Road Pothole Repairs: Usually 7 to 15 days, except during severe monsoon seasons."
        ],
        hi: [
          "कचरा जमा होने की सफाई: सफल पंजीकरण के बाद आमतौर पर 24 से 48 घंटे।",
          "पानी के पाइप का रिसाव (मामूली): 24 घंटे। मुख्य पाइपलाइन फटने में 3 से 5 दिन लग सकते हैं।",
          "स्ट्रीटलाइट खराब होना: बल्ब/वायरिंग की समस्या के आधार पर आमतौर पर 48 घंटे से 3 कार्य दिवस।",
          "सड़क के गड्ढों की मरम्मत: आमतौर पर 7 से 15 दिन, भारी मानसून सीजन को छोड़कर।"
        ]
      }
    },
    {
      id: "faq-4",
      category: "schemes",
      question: {
        en: "How do I check my eligibility for Pradhan Mantri Awas Yojana (PMAY)?",
        hi: "मैं प्रधानमंत्री आवास योजना (PMAY) के लिए अपनी पात्रता कैसे जांचूं?"
      },
      answer: {
        en: "PMAY aims to provide affordable housing. Eligibility is primarily determined by your household's annual income, categorized into economic classes.",
        hi: "PMAY का उद्देश्य किफायती आवास प्रदान करना है। पात्रता मुख्य रूप से आपके परिवार की वार्षिक आय से निर्धारित होती है, जिसे आर्थिक श्रेणियों में बांटा गया है।"
      },
      steps: {
        en: [
          "EWS (Economically Weaker Section): Annual household income up to ₹3 Lakh.",
          "LIG (Low Income Group): Annual household income between ₹3 Lakh to ₹6 Lakh.",
          "The beneficiary family must not own a pucca house in any part of India in their name.",
          "You can apply online via pmaymis.gov.in or offline through Common Service Centres (CSCs)."
        ],
        hi: [
          "EWS (आर्थिक रूप से कमजोर वर्ग): ₹3 लाख तक की वार्षिक पारिवारिक आय।",
          "LIG (अल्प आय वर्ग): ₹3 लाख से ₹6 लाख के बीच वार्षिक पारिवारिक आय।",
          "लाभार्थी परिवार के पास भारत के किसी भी हिस्से में अपने नाम पर पक्का मकान नहीं होना चाहिए।",
          "आप pmaymis.gov.in के माध्यम से ऑनलाइन या कॉमन सर्विस सेंटर (CSC) के माध्यम से ऑफलाइन आवेदन कर सकते हैं।"
        ]
      }
    },
    {
      id: "faq-5",
      category: "identity",
      question: {
        en: "How can I apply for a duplicate PAN card online if my original is lost?",
        hi: "यदि मेरा मूल पैन कार्ड खो गया है तो मैं ऑनलाइन डुप्लीकेट पैन कार्ड के लिए कैसे आवेदन कर सकता हूँ?"
      },
      answer: {
        en: "If your PAN card is lost or damaged, you can request a reprint online through Protean (formerly NSDL) or UTITSL portals without changing your existing PAN number.",
        hi: "यदि आपका पैन कार्ड खो गया है या क्षतिग्रस्त हो गया है, तो आप अपने मौजूदा पैन नंबर को बदले बिना प्रोटीन (NSDL) या UTITSL पोर्टल के माध्यम से ऑनलाइन रीप्रिंट का अनुरोध कर सकते हैं।"
      },
      steps: {
        en: [
          "Go to the official Protean portal 'Reprint of PAN Card'.",
          "Enter your PAN Number, Aadhaar Number, and Date of Birth.",
          "Verify the details and generate an OTP on your registered mobile number/email.",
          "Pay the reprint fee of ₹50 (for dispatch within India). The physical card is delivered in 10 days."
        ],
        hi: [
          "प्रोटीन (NSDL) के आधिकारिक पोर्टल 'Reprint of PAN Card' पर जाएं।",
          "अपना पैन नंबर, आधार नंबर और जन्म तिथि दर्ज करें।",
          "विवरणों को सत्यापित करें और अपने पंजीकृत मोबाइल नंबर/ईमेल पर ओटीपी जनरेट करें।",
          "₹50 का रीप्रिंट शुल्क भुगतान करें (भारत के भीतर वितरण के लिए)। भौतिक कार्ड 10 दिनों में डिलीवर हो जाता है।"
        ]
      }
    },
    {
      id: "faq-6",
      category: "schemes",
      question: {
        en: "What are the benefits of Ayushman Bharat Golden Card (PM-JAY)?",
        hi: "आयुष्मान भारत गोल्डन कार्ड (PM-JAY) के क्या लाभ हैं?"
      },
      answer: {
        en: "The Ayushman Bharat Pradhan Mantri Jan Arogya Yojana is the world's largest government-funded healthcare scheme, designed to protect low-income families from high medical costs.",
        hi: "आयुष्मान भारत प्रधानमंत्री जन आरोग्य योजना दुनिया की सबसे बड़ी सरकार द्वारा वित्तपोषित स्वास्थ्य सेवा योजना है, जिसे कम आय वाले परिवारों को उच्च चिकित्सा लागतों से बचाने के लिए डिज़ाइन किया गया है।"
      },
      steps: {
        en: [
          "Provides free health cover of up to ₹5 Lakh per family per year for secondary and tertiary care hospitalization.",
          "Covers pre-existing conditions from Day 1 of enrollment.",
          "Cashless and paperless service across all empaneled public and private hospitals nationwide.",
          "No restriction on family size, age, or gender."
        ],
        hi: [
          "माध्यमिक और तृतीयक देखभाल अस्पताल में भर्ती होने के लिए प्रति परिवार प्रति वर्ष ₹5 लाख तक का मुफ्त स्वास्थ्य बीमा प्रदान करता है।",
          "पंजीकरण के पहले दिन से ही पहले से मौजूद बीमारियों को कवर करता है।",
          "देशभर के सभी सूचीबद्ध सरकारी और निजी अस्पतालों में कैशलेस और पेपरलेस सेवा।",
          "परिवार के आकार, आयु या लिंग पर कोई प्रतिबंध नहीं है।"
        ]
      }
    }
  ];

  const quickLinks: QuickLink[] = [
    {
      name: { en: "Aadhaar Portal (UIDAI)", hi: "आधार पोर्टल (UIDAI)" },
      desc: { en: "Download Aadhaar, book appointment, update address, check status.", hi: "आधार डाउनलोड करें, अपॉइंटमेंट बुक करें, पता अपडेट करें, स्थिति जांचें।" },
      url: "https://myaadhaar.uidai.gov.in/",
      icon: <UserCheck size={18} className="text-cyan-400" />
    },
    {
      name: { en: "National Voters Portal", hi: "राष्ट्रीय मतदाता पोर्टल" },
      desc: { en: "Apply for new Voter ID card, check polling booth, track status.", hi: "नए वोटर आईडी कार्ड के लिए आवेदन करें, पोलिंग बूथ की जांच करें, ट्रैक करें।" },
      url: "https://voters.eci.gov.in/",
      icon: <FileCheck size={18} className="text-emerald-400" />
    },
    {
      name: { en: "CPGRAMS Portal", hi: "सीपीजीआरएएमएस पोर्टल" },
      desc: { en: "Register public grievances directly with Central & State Government departments.", hi: "केंद्र और राज्य सरकार के विभागों के पास सीधे सार्वजनिक शिकायतें दर्ज करें।" },
      url: "https://pgportal.gov.in/",
      icon: <Megaphone size={18} className="text-amber-400" />
    },
    {
      name: { en: "National Portal of India", hi: "भारत का राष्ट्रीय पोर्टल" },
      desc: { en: "Single-window access to information & services provided by Indian Gov.", hi: "भारत सरकार द्वारा प्रदान की जाने वाली सूचनाओं और सेवाओं तक एकल-खिड़की पहुंच।" },
      url: "https://www.india.gov.in/",
      icon: <Globe size={18} className="text-indigo-400" />
    }
  ];

  // Filtering Logic
  const filteredFaqs = faqData.filter(faq => {
    const matchesCategory = selectedCategory === "all" || faq.category === selectedCategory;
    const searchLower = searchQuery.toLowerCase();
    const matchesSearch = 
      faq.question[lang].toLowerCase().includes(searchLower) ||
      faq.answer[lang].toLowerCase().includes(searchLower) ||
      faq.category.toLowerCase().includes(searchLower);
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-6 w-full" id="faq-tab-container">
      {/* Visual Header Banner */}
      <div className="relative bg-slate-900 border border-slate-800 rounded-2xl p-6 overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl -mr-10 -mt-10 animate-pulse" />
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-xl -ml-8 -mb-8" />
        
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
              <HelpCircle className="text-indigo-400" size={24} />
              <span>{lang === "hi" ? "अक्सर पूछे जाने वाले प्रश्न" : "Civic Knowledge Hub & FAQs"}</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 font-medium">
              {lang === "hi" 
                ? "सरकारी प्रक्रियाओं, पहचान पत्रों और नागरिक अधिकारों को समझने के लिए हमारी मार्गदर्शिका।" 
                : "Your guide to understanding government procedures, ID card applications, and citizen rights."}
            </p>
          </div>
          <div className="flex items-center gap-1 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-bold px-3 py-1.5 rounded-xl self-start md:self-auto shadow-inner shadow-indigo-500/5">
            <Sparkles size={14} className="animate-pulse" />
            <span>{lang === "hi" ? "आधिकारिक मार्गदर्शिका" : "Official Handbooks"}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column: FAQ accordion & search */}
        <div className="lg:col-span-2 space-y-4">
          {/* Search bar & Category filters */}
          <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-4 space-y-3 shadow-md">
            <div className="relative flex items-center">
              <Search className="absolute left-3 text-slate-500" size={16} />
              <input
                type="text"
                placeholder={lang === "hi" ? "विषयों या प्रश्नों को खोजें..." : "Search topics, cards, procedures..."}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-950 text-slate-100 placeholder-slate-500 text-xs sm:text-sm pl-10 pr-4 py-2.5 rounded-xl border border-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/25 transition-all"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery("")} 
                  className="absolute right-3 text-xs text-indigo-400 hover:text-indigo-300 font-bold"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Category selection pill buttons */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {(Object.keys(categories) as Array<keyof typeof categories>).map((catKey) => (
                <button
                  key={catKey}
                  onClick={() => setSelectedCategory(catKey)}
                  className={`px-3 py-1.5 rounded-full text-[10px] sm:text-xs font-semibold transition-all cursor-pointer ${
                    selectedCategory === catKey
                      ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/15"
                      : "bg-slate-950 border border-slate-800 text-slate-400 hover:bg-slate-800 hover:text-slate-200"
                  }`}
                >
                  {categories[catKey][lang]}
                </button>
              ))}
            </div>
          </div>

          {/* FAQS Accordion List */}
          <div className="space-y-2.5">
            <AnimatePresence mode="popLayout">
              {filteredFaqs.length > 0 ? (
                filteredFaqs.map((faq) => {
                  const isExpanded = expandedId === faq.id;
                  return (
                    <motion.div
                      key={faq.id}
                      layout
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ duration: 0.2 }}
                      className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg shadow-black/5"
                    >
                      <button
                        onClick={() => setExpandedId(isExpanded ? null : faq.id)}
                        className="w-full flex items-center justify-between p-4 text-left transition-colors hover:bg-slate-800/40 cursor-pointer"
                      >
                        <span className="font-bold text-slate-100 text-xs sm:text-sm flex items-center gap-2.5">
                          <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                            faq.category === "identity" ? "bg-cyan-400" :
                            faq.category === "voter" ? "bg-emerald-400" :
                            faq.category === "civic" ? "bg-amber-400" : "bg-indigo-400"
                          }`} />
                          {faq.question[lang]}
                        </span>
                        <ChevronDown 
                          size={16} 
                          className={`text-slate-400 shrink-0 transition-transform duration-300 ${isExpanded ? "rotate-180 text-indigo-400" : ""}`} 
                        />
                      </button>

                      <AnimatePresence initial={false}>
                        {isExpanded && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.2, ease: "easeInOut" }}
                          >
                            <div className="px-4 pb-4 border-t border-slate-800/60 pt-3 text-xs sm:text-sm text-slate-300 space-y-3 bg-slate-950/20">
                              <p className="leading-relaxed text-slate-300">
                                {faq.answer[lang]}
                              </p>

                              {faq.steps && (
                                <div className="bg-slate-950/80 rounded-xl p-3 border border-slate-800/80 space-y-2">
                                  <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest flex items-center gap-1">
                                    <Bookmark size={10} />
                                    {lang === "hi" ? "चरण-दर-चरण प्रक्रिया" : "Step-by-Step Procedure"}
                                  </span>
                                  <ol className="list-decimal pl-4 space-y-1.5 text-xs text-slate-400 leading-relaxed">
                                    {faq.steps[lang].map((step, sIdx) => (
                                      <li key={sIdx} className="pl-1">
                                        {step}
                                      </li>
                                    ))}
                                  </ol>
                                </div>
                              )}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  );
                })
              ) : (
                <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-8 text-center space-y-3 shadow-xl">
                  <div className="w-12 h-12 bg-indigo-500/10 rounded-full flex items-center justify-center mx-auto text-indigo-400">
                    <Search size={22} />
                  </div>
                  <p className="text-xs sm:text-sm text-slate-400 font-medium">
                    {lang === "hi" 
                      ? "आपके खोज मानदंड से मेल खाने वाला कोई प्रश्न नहीं मिला। कृपया अन्य शब्द का प्रयास करें।" 
                      : "No matching FAQs found. Try searching for 'Aadhaar', 'Voter', or 'Scheme'."}
                  </p>
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Right column: Quick links */}
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 sm:p-5 shadow-xl space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-2.5">
              <Globe size={18} className="text-indigo-400 shrink-0" />
              <h4 className="font-bold text-slate-100 text-sm">
                {lang === "hi" ? "त्वरित सरकारी लिंक" : "Quick Official Links"}
              </h4>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              {lang === "hi" 
                ? "भारत सरकार के विभिन्न विभागों द्वारा प्रदान की जाने वाली ऑनलाइन सेवाओं के लिए आधिकारिक सरकारी पोर्टल।" 
                : "Official government portals for direct online services and updates across Indian departments."}
            </p>

            <div className="space-y-3 pt-1">
              {quickLinks.map((link, idx) => (
                <a
                  key={idx}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group block bg-slate-950 hover:bg-slate-800/80 border border-slate-800 hover:border-indigo-500/30 rounded-xl p-3 transition-all duration-300"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex gap-2.5">
                      <div className="p-1.5 bg-slate-900 rounded-lg group-hover:bg-slate-950 transition-colors">
                        {link.icon}
                      </div>
                      <div>
                        <h5 className="font-bold text-slate-200 text-xs group-hover:text-white transition-colors flex items-center gap-1">
                          {link.name[lang]}
                        </h5>
                        <p className="text-[10px] text-slate-500 leading-normal mt-0.5 group-hover:text-slate-400 transition-colors">
                          {link.desc[lang]}
                        </p>
                      </div>
                    </div>
                    <ExternalLink size={12} className="text-slate-500 group-hover:text-indigo-400 transition-colors shrink-0 mt-0.5" />
                  </div>
                </a>
              ))}
            </div>

            {/* Security warning card */}
            <div className="bg-amber-500/5 border border-amber-500/10 rounded-xl p-3 text-amber-300 text-[10px] sm:text-xs leading-relaxed flex gap-2">
              <span className="text-amber-500 shrink-0 font-bold">⚠️</span>
              <p className="text-slate-400">
                <strong>{lang === "hi" ? "सुरक्षा टिप:" : "Security Tip:"}</strong>{" "}
                {lang === "hi"
                  ? "हमेशा सुनिश्चित करें कि आप केवल .gov.in या .nic.in डोमेन वाले आधिकारिक सरकारी पोर्टलों का उपयोग कर रहे हैं।"
                  : "Always ensure you are using official domains ending in .gov.in or .nic.in for transaction details."}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
