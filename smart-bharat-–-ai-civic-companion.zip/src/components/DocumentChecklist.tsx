import React from "react";
import { FileText, CheckSquare, Clock, Globe, Printer } from "lucide-react";

export interface DocumentHelpData {
  documentName: string;
  checklist: string[];
  processingTime: string;
  officialPortalName: string;
}

interface DocumentChecklistProps {
  data: DocumentHelpData;
  lang?: "en" | "hi";
}

export const DocumentChecklist: React.FC<DocumentChecklistProps> = ({ data, lang = "en" }) => {
  if (!data) return null;

  const handlePrint = () => {
    // Create a temporary hidden iframe
    const iframe = document.createElement("iframe");
    iframe.style.position = "absolute";
    iframe.style.width = "0px";
    iframe.style.height = "0px";
    iframe.style.border = "none";
    document.body.appendChild(iframe);

    const doc = iframe.contentWindow?.document;
    if (!doc) return;

    const checklistHtml = data.checklist && data.checklist.length > 0 
      ? data.checklist.map(item => `
          <div style="display: flex; align-items: flex-start; margin-bottom: 12px; font-size: 14px; color: #334155;">
            <span style="color: #10b981; margin-right: 10px; font-weight: bold; font-size: 16px;">✓</span>
            <span>${item}</span>
          </div>
        `).join("")
      : `<p style="font-style: italic; color: #64748b;">No specific documents listed.</p>`;

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>${data.documentName} Checklist</title>
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
            body {
              font-family: 'Inter', sans-serif;
              color: #1e293b;
              margin: 40px;
              line-height: 1.5;
            }
            .header {
              display: flex;
              align-items: center;
              justify-content: space-between;
              border-bottom: 2px solid #e2e8f0;
              padding-bottom: 15px;
              margin-bottom: 25px;
            }
            .brand-container {
              display: flex;
              flex-direction: column;
              text-align: center;
              margin-bottom: 15px;
            }
            .brand {
              font-size: 20px;
              font-weight: 700;
              color: #4f46e5;
              letter-spacing: -0.025em;
            }
            .tagline {
              font-size: 11px;
              color: #64748b;
              font-weight: 500;
              margin-top: 2px;
            }
            .tricolor-bar {
              height: 4px;
              background: linear-gradient(to right, #ff9933, #e2e8f0, #138808);
              border-radius: 2px;
              margin-bottom: 20px;
            }
            .doc-title {
              font-size: 22px;
              font-weight: 700;
              color: #0f172a;
              margin-bottom: 10px;
            }
            .section-title {
              font-size: 12px;
              font-weight: 700;
              text-transform: uppercase;
              color: #64748b;
              letter-spacing: 0.05em;
              margin-top: 25px;
              margin-bottom: 15px;
              border-bottom: 1px solid #f1f5f9;
              padding-bottom: 5px;
            }
            .meta-grid {
              display: grid;
              grid-template-columns: 1fr 1fr;
              gap: 15px;
              margin-top: 35px;
              padding-top: 20px;
              border-top: 1px solid #e2e8f0;
            }
            .meta-card {
              background-color: #f8fafc;
              border: 1px solid #f1f5f9;
              border-radius: 8px;
              padding: 12px 15px;
            }
            .meta-label {
              font-size: 11px;
              color: #64748b;
              font-weight: 600;
              text-transform: uppercase;
              margin-bottom: 4px;
            }
            .meta-value {
              font-size: 14px;
              color: #0f172a;
              font-weight: 600;
            }
            .disclaimer {
              margin-top: 50px;
              font-size: 11px;
              color: #94a3b8;
              text-align: center;
              border-top: 1px dashed #e2e8f0;
              padding-top: 15px;
            }
          </style>
        </head>
        <body>
          <div class="brand-container">
            <div class="brand">JanSathi</div>
            <div class="tagline">Har Nagrik Ka Digital Saathi</div>
          </div>
          <div class="tricolor-bar"></div>
          
          <h1 class="doc-title">${data.documentName} Requirements Checklist</h1>
          <p style="font-size: 14px; color: #475569; margin-bottom: 25px;">
            This document outlines the official prerequisites, expected timeline, and verification portal for obtaining a <strong>${data.documentName}</strong>. Keep this checklist handy while compiling your application.
          </p>

          <div class="section-title">Required Documents</div>
          <div style="margin-bottom: 30px;">
            ${checklistHtml}
          </div>

          <div class="meta-grid">
            <div class="meta-card">
              <div class="meta-label">Estimated Processing Time</div>
              <div class="meta-value">${data.processingTime}</div>
            </div>
            <div class="meta-card">
              <div class="meta-label">Official Search / Application Portal</div>
              <div class="meta-value">${data.officialPortalName}</div>
            </div>
          </div>

          <div class="disclaimer">
            Disclaimer: This is a guide prepared by JanSathi AI Companion. Always verify latest mandates, fees, and procedures directly on the official Government portal (${data.officialPortalName}) before filing.
          </div>
          
          <script>
            window.onload = function() {
              window.print();
              setTimeout(function() {
                window.parent.document.body.removeChild(window.frameElement);
              }, 150);
            };
          </script>
        </body>
      </html>
    `;

    doc.open();
    doc.write(htmlContent);
    doc.close();
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 sm:p-5" id="document-checklist">
      <div className="flex items-center justify-between gap-4 mb-3 border-b border-slate-800 pb-2.5">
        <div className="flex items-center gap-2">
          <FileText size={18} className="text-indigo-400" />
          <h4 className="font-bold text-slate-100 text-base">
            {data.documentName} {lang === "hi" ? "दस्तावेज़ सूची" : "Checklist"}
          </h4>
        </div>
        
        <button
          onClick={handlePrint}
          className="flex items-center gap-1.5 bg-indigo-600/10 hover:bg-indigo-600 border border-indigo-500/30 hover:border-indigo-500 text-indigo-400 hover:text-white text-[11px] font-bold px-2.5 py-1.5 rounded-xl transition-all cursor-pointer active:scale-95 shadow-md hover:shadow-indigo-600/20"
          title={lang === "hi" ? "प्रिंट या पीडीएफ डाउनलोड करें" : "Print or save as PDF"}
        >
          <Printer size={13} className="shrink-0" />
          <span>{lang === "hi" ? "प्रिंट / पीडीएफ" : "Print / PDF"}</span>
        </button>
      </div>

      <div className="mb-4">
        <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-2">
          {lang === "hi" ? "आवश्यक दस्तावेज चेकलिस्ट" : "Required Documents Checklist"}
        </span>
        <ul className="space-y-2">
          {data.checklist && data.checklist.length > 0 ? (
            data.checklist.map((doc, idx) => (
              <li key={idx} className="flex gap-2.5 items-start text-xs sm:text-sm text-slate-300">
                <CheckSquare size={16} className="text-emerald-400 shrink-0 mt-0.5" />
                <span>{doc}</span>
              </li>
            ))
          ) : (
            <li className="text-slate-500 italic text-xs">
              {lang === "hi" ? "मॉडल द्वारा कोई दस्तावेज सूचीबद्ध नहीं है।" : "No specific documents listed by model."}
            </li>
          )}
        </ul>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 border-t border-slate-800 pt-3 text-xs">
        <div className="flex gap-2 items-center bg-slate-950 border border-slate-800 rounded-lg p-2.5">
          <Clock size={16} className="text-amber-400 shrink-0" />
          <div>
            <span className="text-slate-400 font-medium block">{lang === "hi" ? "प्रसंस्करण समय" : "Processing Time"}</span>
            <span className="text-slate-200 font-semibold">{data.processingTime}</span>
          </div>
        </div>

        <div className="flex gap-2 items-center bg-slate-950 border border-slate-800 rounded-lg p-2.5">
          <Globe size={16} className="text-blue-400 shrink-0" />
          <div>
            <span className="text-slate-400 font-medium block">{lang === "hi" ? "आधिकारिक पोर्टल" : "Search Portal"}</span>
            <span className="text-slate-200 font-semibold">{data.officialPortalName}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
