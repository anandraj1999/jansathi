import React from "react";
import { motion } from "motion/react";

export function MovingTricolorWave({ 
  opacity = 0.08, 
  height = 120, 
  position = "bottom" 
}: { 
  opacity?: number; 
  height?: number; 
  position?: "top" | "bottom";
}) {
  const isTop = position === "top";
  return (
    <div 
      className={`absolute inset-x-0 pointer-events-none overflow-hidden select-none z-0 ${
        isTop ? "top-0" : "bottom-0"
      }`} 
      style={{ 
        opacity, 
        height,
        transform: isTop ? "scaleY(-1)" : undefined
      }}
    >
      <svg
        className={`absolute left-0 w-[200%] h-full min-w-[2000px] fill-none ${
          isTop ? "top-0" : "bottom-0"
        }`}
        viewBox="0 0 1440 120"
        preserveAspectRatio="none"
      >
        {/* Saffron Wave layer (Top) */}
        <motion.path
          d="M0,45 C240,95 480,15 720,55 C960,95 1200,15 1440,45 L1440,120 L0,120 Z"
          fill="#FF9933"
          animate={{
            x: ["0%", "-50%"],
          }}
          transition={{
            ease: "linear",
            duration: 16,
            repeat: Infinity,
          }}
        />

        {/* White Wave layer (Middle) */}
        <motion.path
          d="M0,60 C240,100 480,25 720,70 C960,110 1200,25 1440,60 L1440,120 L0,120 Z"
          fill="#FFFFFF"
          animate={{
            x: ["-50%", "0%"],
          }}
          transition={{
            ease: "linear",
            duration: 20,
            repeat: Infinity,
          }}
        />

        {/* Green Wave layer (Bottom) */}
        <motion.path
          d="M0,75 C240,105 480,40 720,85 C960,115 1200,45 1440,75 L1440,120 L0,120 Z"
          fill="#138808"
          animate={{
            x: ["0%", "-50%"],
          }}
          transition={{
            ease: "linear",
            duration: 12,
            repeat: Infinity,
          }}
        />
      </svg>
      
      {/* Dynamic Ashoka Chakra overlay floating at the bottom right */}
      <div 
        className={`absolute right-12 w-14 h-14 border border-blue-500/10 rounded-full flex items-center justify-center opacity-40 animate-[spin_30s_linear_infinite] ${
          isTop ? "top-4" : "bottom-4"
        }`}
        style={{
          transform: isTop ? "scaleY(-1)" : undefined
        }}
      >
        <svg viewBox="0 0 100 100" className="w-12 h-12 text-indigo-500/30 fill-none stroke-current" strokeWidth="2.5">
          <circle cx="50" cy="50" r="40" />
          <circle cx="50" cy="50" r="6" className="fill-indigo-500/20" />
          {Array.from({ length: 24 }).map((_, i) => {
            const angle = (i * 360) / 24;
            const rad = (angle * Math.PI) / 180;
            const x2 = 50 + 40 * Math.cos(rad);
            const y2 = 50 + 40 * Math.sin(rad);
            return <line key={i} x1="50" y1="50" x2={x2} y2={y2} />;
          })}
        </svg>
      </div>
    </div>
  );
}
