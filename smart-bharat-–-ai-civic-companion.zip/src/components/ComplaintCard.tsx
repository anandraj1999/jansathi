import React, { useState } from "react";
import { AlertTriangle, MapPin, Copy, Check, FileText, Clock } from "lucide-react";

export interface ComplaintData {
  category: string;
  location: string;
  description: string;
  urgency: string; // "Low" | "Medium" | "High"
  complaintId?: string;
  status: string; // "Ready" | "Incomplete"
}

interface ComplaintCardProps {
  data: ComplaintData;
  date?: Date;
  onCopySuccess?: () => void;
}

export const ComplaintCard: React.FC<ComplaintCardProps> = ({ data, date, onCopySuccess }) => {
  const [copied, setCopied] = useState(false);

  const getUrgencyStyles = (urgency: string) => {
    switch (urgency?.toLowerCase()) {
      case "high":
        return "bg-rose-500/10 text-rose-400 border-rose-500/30";
      case "medium":
        return "bg-amber-500/10 text-amber-400 border-amber-500/30";
      default:
        return "bg-emerald-500/10 text-emerald-400 border-emerald-500/30";
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category?.toLowerCase()) {
      case "roads": return "text-slate-300 bg-slate-800";
      case "water": return "text-blue-400 bg-blue-950/50";
      case "electricity": return "text-yellow-400 bg-yellow-950/50";
      case "sanitation": return "text-indigo-400 bg-indigo-950/50";
      case "garbage": return "text-orange-400 bg-orange-950/50";
      default: return "text-teal-400 bg-teal-950/50";
    }
  };

  const formattedDraft = `CIVIC COMPLAINT REPORT
------------------------
Complaint ID : ${data.complaintId || "DRAFT"}
Status       : ${data.status === "Ready" ? "Ready for Submission" : "Awaiting Details"}
Category     : ${data.category}
Location     : ${data.location === "missing" ? "NOT PROVIDED" : data.location}
Urgency      : ${data.urgency}
Reported On  : ${date ? date.toLocaleDateString() : new Date().toLocaleDateString()}

Description  :
${data.description}

Generated via JanSathi AI Civic Companion.`;

  const handleCopy = () => {
    navigator.clipboard.writeText(formattedDraft);
    setCopied(true);
    if (onCopySuccess) onCopySuccess();
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl shadow-lg shadow-black/20 overflow-hidden text-sm" id={`complaint-card-${data.complaintId || "draft"}`}>
      {/* Top Header with Tricolor accent */}
      <div className="h-1 bg-gradient-to-r from-amber-500 via-zinc-200 to-emerald-500" />
      
      <div className="p-4 sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border border-slate-700/30 ${getCategoryColor(data.category)}`}>
              {data.category}
            </span>
            <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium border ${getUrgencyStyles(data.urgency)}`}>
              {data.urgency} Urgency
            </span>
          </div>
          
          <div className="text-xs text-slate-400 font-mono flex items-center gap-1">
            <Clock size={12} />
            {date ? date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : "Just now"}
          </div>
        </div>

        <h4 className="font-semibold text-slate-100 text-base mb-2 flex items-center gap-1.5">
          <FileText size={18} className="text-indigo-400" />
          {data.status === "Ready" ? (
            <span className="text-emerald-400">Complaint Draft Ready</span>
          ) : (
            <span className="text-amber-400">Draft Incomplete (Location Missing)</span>
          )}
        </h4>

        {data.complaintId && (
          <div className="bg-slate-950 border border-slate-800 rounded px-3 py-1 text-xs font-mono inline-block text-slate-300 mb-3">
            ID: <span className="font-semibold text-indigo-400">{data.complaintId}</span>
          </div>
        )}

        <p className="text-slate-300 bg-slate-950 p-3 rounded-lg border border-slate-800 mb-4 whitespace-pre-wrap leading-relaxed">
          {data.description}
        </p>

        <div className="space-y-2 mb-4 border-t border-slate-800 pt-3 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <MapPin size={14} className="text-slate-500 shrink-0" />
            <span>
              <strong>Location:</strong>{" "}
              {data.location === "missing" ? (
                <span className="text-rose-400 font-medium bg-rose-950/40 px-1.5 py-0.5 rounded border border-rose-500/20">
                  Missing (Please tell AI your location)
                </span>
              ) : (
                <span className="text-slate-200">{data.location}</span>
              )}
            </span>
          </div>
        </div>

        {data.status === "Incomplete" && (
          <div className="bg-amber-950/40 border border-amber-500/20 rounded-lg p-3 text-amber-300 mb-4 flex gap-2">
            <AlertTriangle size={16} className="text-amber-500 shrink-0 mt-0.5" />
            <p className="text-xs leading-relaxed">
              <strong>Location Needed:</strong> Please reply to the chat with your location/landmark to assign a unique Complaint ID.
            </p>
          </div>
        )}

        <div className="flex justify-end">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-medium px-4 py-2 rounded-lg transition-all text-xs active:scale-95 cursor-pointer shadow-md shadow-indigo-600/10"
            aria-label="Copy complaint text"
          >
            {copied ? (
              <>
                <Check size={14} />
                <span>Copied!</span>
              </>
            ) : (
              <>
                <Copy size={14} />
                <span>Copy Complaint Format</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
