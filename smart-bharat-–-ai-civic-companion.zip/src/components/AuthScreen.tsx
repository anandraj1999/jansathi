import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  User, 
  Mail, 
  Lock, 
  Sparkles, 
  Check, 
  AlertTriangle, 
  ShieldCheck, 
  ChevronRight,
  Smile,
  Info,
  Globe
} from "lucide-react";
import { MovingTricolorWave } from "./MovingTricolorWave";
// @ts-ignore
import jansathiRobotMascot from "../assets/images/jansathi_robot_mascot_1783411111585.jpg";

interface AuthScreenProps {
  lang: "en" | "hi";
  onLangChange: (lang: "en" | "hi") => void;
  onLoginSuccess: (user: { name: string; email: string; avatar: string }) => void;
}

const presetAvatars = [
  "🦁", "🐼", "🦊", "🐯", "🐨", "🦉", "🎯", "🤖", "🚀", "🎨"
];

export const AuthScreen: React.FC<AuthScreenProps> = ({ lang, onLangChange, onLoginSuccess }) => {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [selectedAvatar, setSelectedAvatar] = useState("🤖");
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Quick helper translation inside auth
  const text = {
    title: { en: "JanSathi", hi: "जनसाथी" },
    subtitle: { en: "JanSathi — Har Nagrik Ka Digital Saathi", hi: "जनसाथी — हर नागरिक का डिजिटल साथी" },
    loginTab: { en: "Login", hi: "लॉगिन" },
    signupTab: { en: "Sign Up", hi: "पंजीकरण" },
    fullName: { en: "Full Name", hi: "पूरा नाम" },
    email: { en: "Email Address", hi: "ईमेल पता" },
    password: { en: "Password", hi: "पासवर्ड" },
    avatarSelect: { en: "Choose Your Avatar Profile", hi: "अपनी प्रोफ़ाइल अवतार चुनें" },
    guestBtn: { en: "Continue as Guest", hi: "अतिथि के रूप में आगे बढ़ें" },
    submitLogin: { en: "Access Companion", hi: "साथी का उपयोग करें" },
    submitSignup: { en: "Create Free Account", hi: "मुफ़्त खाता बनाएं" },
    noAccount: { en: "Don't have an account?", hi: "खाता नहीं है?" },
    haveAccount: { en: "Already registered?", hi: "पहले से पंजीकृत हैं?" },
    switchToSignup: { en: "Sign Up Now", hi: "अभी पंजीकरण करें" },
    switchToLogin: { en: "Login Now", hi: "अभी लॉगिन करें" },
    emailRequired: { en: "Please enter your email and password.", hi: "कृपया अपना ईमेल और पासवर्ड दर्ज करें।" },
    signupSuccess: { en: "Account created successfully! Logging you in...", hi: "खाता सफलतापूर्वक बन गया! आपको लॉगिन किया जा रहा है..." },
    invalidCreds: { en: "Invalid email or password.", hi: "अमान्य ईमेल या पासवर्ड।" },
    signupRequired: { en: "All fields are required to sign up.", hi: "साइन अप करने के लिए सभी फ़ील्ड आवश्यक हैं।" },
    infoText: { en: "Your credentials are saved locally in your browser for dynamic testing.", hi: "गतिशील परीक्षण के लिए आपके क्रेडेंशियल आपके ब्राउज़र में स्थानीय रूप से सहेजे गए हैं।" }
  };

  const handleGuestLogin = () => {
    const guestUser = {
      name: lang === "hi" ? "नागरिक अतिथि" : "Citizen Guest",
      email: "guest@jansathi.gov.in",
      avatar: "👤"
    };
    onLoginSuccess(guestUser);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!email.trim() || !password.trim()) {
      setError(text.emailRequired[lang]);
      return;
    }

    // Retrieve users from localStorage
    const usersStr = localStorage.getItem("jansathi_users") || "[]";
    const users = JSON.parse(usersStr);

    // Look for matching user
    const matchedUser = users.find((u: any) => u.email.toLowerCase() === email.toLowerCase().trim() && u.password === password);

    if (matchedUser) {
      onLoginSuccess({
        name: matchedUser.name,
        email: matchedUser.email,
        avatar: matchedUser.avatar
      });
    } else {
      // Allow general demo bypass: if they enter demo@demo.com or any mock, we check if it is default
      if (email.toLowerCase().trim() === "demo@jansathi.in" && password === "demo123") {
        onLoginSuccess({
          name: lang === "hi" ? "राम कुमार" : "Ram Kumar",
          email: "demo@jansathi.in",
          avatar: "🇮🇳"
        });
      } else {
        setError(text.invalidCreds[lang]);
      }
    }
  };

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!name.trim() || !email.trim() || !password.trim()) {
      setError(text.signupRequired[lang]);
      return;
    }

    const usersStr = localStorage.getItem("jansathi_users") || "[]";
    const users = JSON.parse(usersStr);

    // Check if user already exists
    const exists = users.some((u: any) => u.email.toLowerCase() === email.toLowerCase().trim());
    if (exists) {
      setError(lang === "hi" ? "यह ईमेल पहले से ही पंजीकृत है।" : "This email is already registered.");
      return;
    }

    const newUser = {
      name: name.trim(),
      email: email.trim(),
      password: password,
      avatar: selectedAvatar
    };

    users.push(newUser);
    localStorage.setItem("jansathi_users", JSON.stringify(users));
    
    setSuccess(text.signupSuccess[lang]);
    setTimeout(() => {
      onLoginSuccess({
        name: newUser.name,
        email: newUser.email,
        avatar: newUser.avatar
      });
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-[#030712] flex flex-col items-center justify-center p-4 relative overflow-hidden font-sans select-none bg-[radial-gradient(#1f2937_1px,transparent_1px)] [background-size:16px_16px]">
      {/* Absolute floating lights */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl animate-pulse -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl animate-pulse translate-x-1/2 translate-y-1/2" />

      {/* WAVE LIKE TRICOLOR MOVING BACKGROUND AT THE BOTTOM OF LOGIN PAGE */}
      <MovingTricolorWave opacity={0.22} height={180} />

      {/* WAVE LIKE TRICOLOR MOVING BACKGROUND AT THE TOP OF LOGIN PAGE */}
      <MovingTricolorWave position="top" opacity={0.22} height={180} />

      {/* Main card box */}
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl shadow-black/60 flex flex-col"
        id="auth-card"
      >
        {/* Dynamic English/Hindi Translator Toggle inside Login Page */}
        <button
          type="button"
          onClick={() => onLangChange(lang === "en" ? "hi" : "en")}
          className="absolute top-4 right-4 flex items-center gap-1.5 bg-slate-800/90 hover:bg-slate-700 border border-slate-700 text-slate-200 text-[10px] font-bold px-2.5 py-1.5 rounded-xl transition-all cursor-pointer shadow-md select-none z-20 hover:scale-105 active:scale-95"
        >
          <Globe size={11} className="text-indigo-400 animate-pulse" />
          <span>{lang === "en" ? "हिंदी" : "English"}</span>
        </button>

        {/* Colorful tricolor top glowing banner */}
        <div className="h-1.5 bg-gradient-to-r from-amber-500 via-zinc-100 to-emerald-500" />

        <div className="p-6 sm:p-8 flex flex-col flex-1">
          {/* Brand header */}
          <div className="text-center space-y-2 mb-6">
            {/* 3D Robot Image with Tricolour border */}
            <div className="relative w-24 h-24 mx-auto mb-2 flex items-center justify-center">
              {/* Pulsing Outer Glow */}
              <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-[#FF9933]/20 via-indigo-500/10 to-[#138808]/20 blur-lg animate-pulse" />
              
              {/* Spinning Tricolour Outer Border */}
              <div className="absolute inset-0 rounded-full p-[2px] bg-gradient-to-tr from-[#FF9933] via-slate-700 to-[#138808] animate-[spin_12s_linear_infinite]" />
              
              {/* Image Container */}
              <div className="relative w-[88px] h-[88px] rounded-full bg-slate-950 border border-slate-800 overflow-hidden shadow-2xl flex items-center justify-center">
                <img 
                  src={jansathiRobotMascot} 
                  alt="JanSathi 3D Robot Mascot" 
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transform hover:scale-110 transition-transform duration-500"
                />
              </div>
            </div>

            {/* Tricolour website name */}
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight select-none filter drop-shadow-[0_4px_6px_rgba(0,0,0,0.5)]">
              {lang === "hi" ? (
                <>
                  <span className="text-[#FF9933]">जन</span>
                  <span className="text-slate-100">सा</span>
                  <span className="text-[#138808]">थी</span>
                </>
              ) : (
                <>
                  <span className="text-[#FF9933]">Jan</span>
                  <span className="text-slate-100">Sa</span>
                  <span className="text-[#138808]">thi</span>
                </>
              )}
            </h1>

            <p className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
              {text.subtitle[lang]}
            </p>
          </div>

          {/* Toggle buttons */}
          <div className="grid grid-cols-2 bg-slate-950 border border-slate-800 p-1 rounded-2xl gap-1 mb-6">
            <button
              onClick={() => { setMode("login"); setError(null); }}
              className={`py-2 text-xs sm:text-sm font-bold rounded-xl transition-all cursor-pointer ${
                mode === "login" 
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/15" 
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              {text.loginTab[lang]}
            </button>
            <button
              onClick={() => { setMode("signup"); setError(null); }}
              className={`py-2 text-xs sm:text-sm font-bold rounded-xl transition-all cursor-pointer ${
                mode === "signup" 
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/15" 
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              {text.signupTab[lang]}
            </button>
          </div>

          <AnimatePresence mode="wait">
            {error && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="bg-rose-500/10 border border-rose-500/20 rounded-xl p-3 text-rose-400 text-xs flex gap-2 mb-4 items-center"
              >
                <AlertTriangle size={15} className="shrink-0" />
                <span className="font-semibold">{error}</span>
              </motion.div>
            )}

            {success && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-3 text-emerald-400 text-xs flex gap-2 mb-4 items-center"
              >
                <Check size={15} className="shrink-0 animate-bounce" />
                <span className="font-semibold">{success}</span>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Core forms */}
          <form onSubmit={mode === "login" ? handleLogin : handleSignup} className="space-y-4">
            <AnimatePresence mode="popLayout">
              {mode === "signup" && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.2 }}
                  className="space-y-1"
                >
                  <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                    {text.fullName[lang]}
                  </label>
                  <div className="relative flex items-center">
                    <User size={16} className="absolute left-3.5 text-slate-500" />
                    <input
                      type="text"
                      placeholder={lang === "hi" ? "नाम प्रविष्ट करें" : "e.g. Anand Kumar"}
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-slate-950 text-slate-100 placeholder-slate-600 text-xs sm:text-sm pl-11 pr-4 py-3 rounded-xl border border-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/25 focus:border-indigo-500/40 transition-all"
                    />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                {text.email[lang]}
              </label>
              <div className="relative flex items-center">
                <Mail size={16} className="absolute left-3.5 text-slate-500" />
                <input
                  type="email"
                  placeholder={lang === "hi" ? "अपना ईमेल पता दर्ज करें" : "e.g. name@example.com"}
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-950 text-slate-100 placeholder-slate-600 text-xs sm:text-sm pl-11 pr-4 py-3 rounded-xl border border-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/25 focus:border-indigo-500/40 transition-all"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                {text.password[lang]}
              </label>
              <div className="relative flex items-center">
                <Lock size={16} className="absolute left-3.5 text-slate-500" />
                <input
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-950 text-slate-100 placeholder-slate-600 text-xs sm:text-sm pl-11 pr-4 py-3 rounded-xl border border-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/25 focus:border-indigo-500/40 transition-all"
                />
              </div>
            </div>

            {/* Avatar Select on Sign Up */}
            <AnimatePresence mode="popLayout">
              {mode === "signup" && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.2 }}
                  className="space-y-2 pt-1"
                >
                  <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                    {text.avatarSelect[lang]}
                  </label>
                  <div className="flex flex-wrap gap-2 justify-between bg-slate-950 p-2.5 rounded-2xl border border-slate-800/80">
                    {presetAvatars.map((av) => (
                      <button
                        key={av}
                        type="button"
                        onClick={() => setSelectedAvatar(av)}
                        className={`text-lg sm:text-xl w-8 h-8 flex items-center justify-center rounded-lg transition-transform active:scale-90 cursor-pointer ${
                          selectedAvatar === av 
                            ? "bg-indigo-600 scale-110 shadow-md shadow-indigo-600/30" 
                            : "hover:bg-slate-900"
                        }`}
                      >
                        {av}
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Login details tooltip */}
            {mode === "login" && (
              <div className="bg-indigo-500/5 border border-indigo-500/10 rounded-xl p-2.5 text-indigo-300 text-[10px] leading-relaxed flex items-start gap-2">
                <Info size={14} className="text-indigo-400 shrink-0 mt-0.5" />
                <p className="text-slate-400">
                  {lang === "hi"
                    ? "त्वरित प्रदर्शन परीक्षण के लिए, उपयोग करें: demo@jansathi.in पासवर्ड: demo123"
                    : "For quick demo testing, use: demo@jansathi.in with password: demo123"}
                </p>
              </div>
            )}

            {/* Submit Actions */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 rounded-xl transition-all cursor-pointer active:scale-95 text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-lg shadow-indigo-600/20"
              >
                <span>{mode === "login" ? text.submitLogin[lang] : text.submitSignup[lang]}</span>
                <ChevronRight size={16} />
              </button>
            </div>
          </form>

          {/* Guest Portal Bypass */}
          <div className="mt-4 border-t border-slate-800/60 pt-4 text-center">
            <button
              onClick={handleGuestLogin}
              className="text-xs bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white transition-all font-bold px-4 py-2 rounded-xl inline-flex items-center gap-1.5 cursor-pointer active:scale-95"
            >
              <Smile size={14} className="text-amber-400" />
              <span>{text.guestBtn[lang]}</span>
            </button>
          </div>

          {/* Bottom Switch Links */}
          <div className="mt-6 text-center text-xs">
            <span className="text-slate-500 font-medium">
              {mode === "login" ? text.noAccount[lang] : text.haveAccount[lang]}{" "}
            </span>
            <button
              onClick={() => {
                setMode(mode === "login" ? "signup" : "login");
                setError(null);
              }}
              className="text-indigo-400 hover:text-indigo-300 font-bold underline cursor-pointer"
            >
              {mode === "login" ? text.switchToSignup[lang] : text.switchToLogin[lang]}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
