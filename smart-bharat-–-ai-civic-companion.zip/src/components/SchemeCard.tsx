import React from "react";
import { Award, CheckCircle2, Gift } from "lucide-react";

export interface Scheme {
  name: string;
  eligibility: string;
  benefits: string;
}

interface SchemeCardProps {
  schemes: Scheme[];
}

export const SchemeCard: React.FC<SchemeCardProps> = ({ schemes }) => {
  if (!schemes || schemes.length === 0) return null;

  return (
    <div className="space-y-4" id="scheme-card-container">
      <div className="flex items-center gap-2 mb-1">
        <Award size={20} className="text-[#FF9933]" />
        <h4 className="font-semibold text-slate-200 text-sm">
          Matched Schemes Recommendation ({schemes.length})
        </h4>
      </div>

      <div className="grid gap-3 sm:grid-cols-1">
        {schemes.map((scheme, idx) => (
          <div 
            key={idx}
            className="bg-slate-900/50 border border-slate-800 rounded-xl p-4 shadow-sm relative overflow-hidden"
          >
            {/* Visual marker decoration */}
            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-tr from-transparent to-amber-500/5 rounded-full -mr-8 -mt-8" />
            
            <h5 className="font-bold text-slate-100 text-base mb-2.5 flex items-center gap-2">
              <span className="flex items-center justify-center w-5 h-5 rounded-full bg-indigo-600 text-white text-[10px] font-bold">
                {idx + 1}
              </span>
              {scheme.name}
            </h5>

            <div className="space-y-2 text-xs">
              <div className="flex gap-2">
                <CheckCircle2 size={14} className="text-emerald-400 mt-0.5 shrink-0" />
                <div>
                  <strong className="text-slate-300">Eligibility:</strong>{" "}
                  <span className="text-slate-400 leading-relaxed">{scheme.eligibility}</span>
                </div>
              </div>

              <div className="flex gap-2">
                <Gift size={14} className="text-amber-400 mt-0.5 shrink-0" />
                <div>
                  <strong className="text-slate-300">Key Benefits:</strong>{" "}
                  <span className="text-slate-400 leading-relaxed">{scheme.benefits}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
