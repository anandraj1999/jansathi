import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Volume2, VolumeX, Sparkles, MessageSquare } from "lucide-react";

interface WelcomeAvatar3DProps {
  lang: "en" | "hi";
  userName?: string;
}

export function WelcomeAvatar3D({ lang, userName }: WelcomeAvatar3DProps) {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isBlinking, setIsBlinking] = useState(false);
  const [showBubble, setShowBubble] = useState(true);

  // Digital eyes blinking logic
  useEffect(() => {
    const interval = setInterval(() => {
      setIsBlinking(true);
      setTimeout(() => setIsBlinking(false), 150);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const nameToUse = userName || (lang === "hi" ? "नागरिक" : "Citizen");

  const greetingText = lang === "hi" 
    ? `नमस्ते ${nameToUse}! जनसाथी — हर नागरिक का डिजिटल साथी में आपका स्वागत है। आज मैं आपकी क्या सहायता कर सकता हूँ?`
    : `Namaste ${nameToUse}! Welcome to JanSathi — Har Nagrik Ka Digital Saathi. How can I assist you today?`;

  const playWelcomeSpeech = () => {
    if (typeof window === "undefined" || !window.speechSynthesis) return;

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(greetingText);
    utterance.lang = lang === "hi" ? "hi-IN" : "en-IN";
    utterance.rate = 0.95;
    
    utterance.onend = () => {
      setIsSpeaking(false);
    };

    utterance.onerror = () => {
      setIsSpeaking(false);
    };

    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="relative flex flex-col md:flex-row items-center gap-6 p-5 bg-gradient-to-br from-slate-900/90 to-indigo-950/40 border border-indigo-500/20 rounded-2xl shadow-xl backdrop-blur-md mb-6 overflow-hidden group">
      {/* Dynamic Ambient Glow Behind Avatar */}
      <div className={`absolute top-1/2 left-12 w-36 h-36 -translate-y-1/2 rounded-full bg-indigo-500/10 blur-2xl transition-all duration-1000 ${
        isSpeaking ? "bg-emerald-500/20 scale-125" : "group-hover:bg-indigo-500/15"
      }`} />

      {/* 3D AVATAR MODEL CONSTRUCTED WITH NESTED GLASSMORPHIC SHAPES */}
      <div className="relative w-28 h-28 flex-shrink-0 flex items-center justify-center cursor-pointer select-none" onClick={playWelcomeSpeech}>
        {/* Futuristic Outer Orbit Ring */}
        <motion.div 
          className={`absolute inset-0 rounded-full border border-dashed border-indigo-400/20 ${
            isSpeaking ? "animate-[spin_4s_linear_infinite] border-emerald-400/40" : "animate-[spin_12s_linear_infinite]"
          }`}
        />

        {/* Outer Halo ring with real-time breathing scale */}
        <motion.div
          animate={{
            scale: isSpeaking ? [1, 1.12, 1] : [1, 1.05, 1],
            rotate: [0, 360],
          }}
          transition={{
            scale: { duration: 2, repeat: Infinity, ease: "easeInOut" },
            rotate: { duration: 20, repeat: Infinity, ease: "linear" }
          }}
          className={`absolute w-24 h-24 rounded-full bg-gradient-to-tr from-indigo-500/10 via-amber-500/5 to-emerald-500/10 p-[2px] shadow-lg shadow-indigo-500/5 ${
            isSpeaking ? "shadow-emerald-500/15" : ""
          }`}
        />

        {/* Main Head: 3D Metallic Sphere */}
        <motion.div
          animate={{
            y: [0, -4, 0],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="relative w-20 h-20 rounded-full bg-radial-gradient from-slate-700 via-slate-900 to-black border border-slate-700/60 flex flex-col items-center justify-center shadow-[inset_0_4px_12px_rgba(255,255,255,0.15),0_10px_20px_rgba(0,0,0,0.6)]"
        >
          {/* Cybernetic Crown Panel */}
          <div className="absolute top-1.5 w-8 h-1 bg-gradient-to-r from-indigo-500 to-cyan-400 rounded-full shadow-xs" />

          {/* Eye Visor/Display Frame */}
          <div className="w-14 h-6 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-around px-2.5 shadow-inner">
            {/* Left Digital Eye */}
            <motion.div 
              animate={{
                scaleY: isBlinking ? 0.1 : 1,
              }}
              className={`w-3.5 h-3.5 rounded-full bg-gradient-to-b from-cyan-300 to-indigo-500 shadow-[0_0_8px_rgba(34,211,238,0.7)] ${
                isSpeaking ? "from-emerald-300 to-teal-500 shadow-[0_0_10px_rgba(52,211,153,0.8)]" : ""
              }`}
            />
            {/* Right Digital Eye */}
            <motion.div 
              animate={{
                scaleY: isBlinking ? 0.1 : 1,
              }}
              className={`w-3.5 h-3.5 rounded-full bg-gradient-to-b from-cyan-300 to-indigo-500 shadow-[0_0_8px_rgba(34,211,238,0.7)] ${
                isSpeaking ? "from-emerald-300 to-teal-500 shadow-[0_0_10px_rgba(52,211,153,0.8)]" : ""
              }`}
            />
          </div>

          {/* Speaker Mouth Matrix */}
          <div className="mt-2.5 flex gap-[2px] h-2.5 items-center justify-center">
            {isSpeaking ? (
              // Talking Waveform Lines
              [1, 2, 3, 4, 3, 2, 1].map((_, idx) => (
                <motion.div
                  key={idx}
                  className="w-[2px] bg-emerald-400 rounded-full"
                  animate={{
                    height: ["4px", "14px", "4px"]
                  }}
                  transition={{
                    duration: 0.5,
                    repeat: Infinity,
                    delay: idx * 0.08,
                    ease: "easeInOut"
                  }}
                />
              ))
            ) : (
              // Idle smile matrix
              <>
                <div className="w-1 h-1 bg-indigo-500/60 rounded-full" />
                <div className="w-3.5 h-[2px] bg-indigo-400 rounded-full" />
                <div className="w-1 h-1 bg-indigo-500/60 rounded-full" />
              </>
            )}
          </div>

          {/* Floating Robot Antenna */}
          <div className="absolute -top-3 w-1.5 h-3.5 bg-slate-700 rounded-full flex flex-col items-center">
            <motion.div 
              animate={{
                scale: isSpeaking ? [1, 1.3, 1] : 1,
                backgroundColor: isSpeaking ? ["#10B981", "#34D399", "#10B981"] : ["#6366F1", "#818CF8", "#6366F1"]
              }}
              className="w-2.5 h-2.5 rounded-full bg-indigo-500 shadow-[0_0_6px_rgba(99,102,241,0.6)]"
              transition={{ duration: 1, repeat: Infinity }}
            />
          </div>
        </motion.div>

        {/* 3D Glass pedestal platform */}
        <div className="absolute bottom-1 w-14 h-2 bg-slate-800/80 rounded-full border border-slate-700/50 shadow-md blur-[1px]" />
      </div>

      {/* SPEECH BUBBLE & INFORMATION CARD */}
      <div className="flex-1 space-y-2 text-center md:text-left">
        <AnimatePresence>
          {showBubble && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="relative bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-lg"
            >
              {/* Triangle pointer for speech bubble */}
              <div className="hidden md:block absolute top-1/2 -left-2.5 -translate-y-1/2 w-0 h-0 border-t-8 border-t-transparent border-r-8 border-r-slate-800 border-b-8 border-b-transparent" />
              
              <div className="flex items-start gap-2.5">
                <Sparkles size={16} className="text-amber-400 shrink-0 mt-0.5" />
                <div className="flex-1 text-xs sm:text-sm text-slate-200 font-medium leading-relaxed">
                  {greetingText}
                </div>
              </div>

              {/* Action row */}
              <div className="mt-3 flex items-center justify-between gap-4">
                <button
                  onClick={playWelcomeSpeech}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                    isSpeaking 
                      ? "bg-rose-500/10 text-rose-400 border-rose-500/25 hover:bg-rose-500/20" 
                      : "bg-indigo-600 hover:bg-indigo-500 text-white border-transparent shadow-md shadow-indigo-600/15"
                  }`}
                >
                  {isSpeaking ? (
                    <>
                      <VolumeX size={13} className="shrink-0" />
                      <span>{lang === "hi" ? "आवाज बंद करें" : "Stop Voice"}</span>
                    </>
                  ) : (
                    <>
                      <Volume2 size={13} className="shrink-0 animate-bounce" />
                      <span>{lang === "hi" ? "आवाज सुनें" : "Listen Aloud"}</span>
                    </>
                  )}
                </button>

                <span className="text-[10px] text-slate-500 font-bold tracking-wide flex items-center gap-1">
                  <MessageSquare size={10} />
                  {lang === "hi" ? "3D एआई साथी" : "3D AI Companion"}
                </span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
