import React, { useState } from "react";
import { Play, CheckCircle2, XCircle, Loader2, Info, ChevronRight, Check } from "lucide-react";

interface TestScenario {
  id: number;
  name: string;
  query: string;
  expectedIntent: string;
  description: string;
  status: "idle" | "running" | "passed" | "failed";
  actualIntent?: string;
  errorMessage?: string;
  responsePreview?: any;
}

interface ValidationSuiteProps {
  onAddTestComplaints: (complaint: any) => void;
}

export const ValidationSuite: React.FC<ValidationSuiteProps> = ({ onAddTestComplaints }) => {
  const [scenarios, setScenarios] = useState<TestScenario[]>([
    {
      id: 1,
      name: "Scenario 1: Complaint Extraction",
      query: "There is water clogging on Main Road near Sector 5, Noida due to heavy rains. It's causing major traffic jam and risks accidents.",
      expectedIntent: "COMPLAINT",
      description: "Extracts category ('Water' or 'Sanitation'), location ('Sector 5, Noida'), urgency ('High'), and generates a Complaint ID.",
      status: "idle",
    },
    {
      id: 2,
      name: "Scenario 2: Scheme Eligibility Finder",
      query: "I am a 45 year old farmer from Uttar Pradesh with an annual income of 1.5 lakhs. What government schemes qualify for me?",
      expectedIntent: "SCHEME_FINDER",
      description: "Parses profile traits (age 45, farmer, UP, 1.5L income) and returns 2-3 matched Central/State schemes.",
      status: "idle",
    },
    {
      id: 3,
      name: "Scenario 3: Document Checklist Help",
      query: "How can I apply for a new PAN card? What are the documents required?",
      expectedIntent: "DOCUMENT_HELP",
      description: "Recognizes PAN card request and returns a precise physical/digital document checklist and the official portal.",
      status: "idle",
    },
  ]);

  const [isRunning, setIsRunning] = useState(false);
  const [overallStatus, setOverallStatus] = useState<"idle" | "running" | "passed" | "failed">("idle");

  const runAllTests = async () => {
    setIsRunning(true);
    setOverallStatus("running");

    // Reset status
    setScenarios(prev => prev.map(s => ({ ...s, status: "running", actualIntent: undefined, responsePreview: undefined, errorMessage: undefined })));

    let allPassed = true;

    for (let i = 0; i < scenarios.length; i++) {
      const scenario = scenarios[i];

      // Update current scenario state to running
      setScenarios(prev => prev.map(s => s.id === scenario.id ? { ...s, status: "running" } : s));

      try {
        const response = await fetch("/api/chat", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            message: scenario.query,
            history: [],
          }),
        });

        if (!response.ok) {
          throw new Error(`Server returned status: ${response.status}`);
        }

        const data = await response.json();

        // Perform validation conditions
        let passed = false;
        if (data && data.intent === scenario.expectedIntent) {
          if (scenario.expectedIntent === "COMPLAINT") {
            // Must have category, location and description
            const c = data.complaintData;
            passed = !!c && !!c.category && c.location !== "missing" && !!c.urgency;
            // Add to session complaints list automatically so they see it in their session list!
            if (passed && c.status === "Ready") {
              onAddTestComplaints({
                complaintId: c.complaintId || "SB-COMP-TEST",
                category: c.category,
                location: c.location,
                description: c.description,
                urgency: c.urgency,
                status: c.status,
                timestamp: new Date()
              });
            }
          } else if (scenario.expectedIntent === "SCHEME_FINDER") {
            // Must recommend schemes or ask questions
            passed = !!data.schemeFinderData && (!!data.schemeFinderData.recommendedSchemes || !!data.schemeFinderData.questionsAsked);
          } else if (scenario.expectedIntent === "DOCUMENT_HELP") {
            // Must have checklist
            passed = !!data.documentHelpData && Array.isArray(data.documentHelpData.checklist) && data.documentHelpData.checklist.length > 0;
          }
        }

        if (!passed) {
          allPassed = false;
        }

        setScenarios(prev => prev.map(s => s.id === scenario.id ? {
          ...s,
          status: passed ? "passed" : "failed",
          actualIntent: data.intent,
          responsePreview: data,
          errorMessage: passed ? undefined : "Schema validation failed: Structured keys were incomplete or incorrectly structured.",
        } : s));

      } catch (err: any) {
        allPassed = false;
        setScenarios(prev => prev.map(s => s.id === scenario.id ? {
          ...s,
          status: "failed",
          errorMessage: err.message || "Failed to contact local server",
        } : s));
      }
    }

    setOverallStatus(allPassed ? "passed" : "failed");
    setIsRunning(false);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm text-sm" id="validation-suite">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div>
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            Civic AI Validation Suite
          </h3>
          <p className="text-xs text-slate-500">
            For judges & developers: Verifies real-time intent classification and JSON schema compliance.
          </p>
        </div>

        <button
          onClick={runAllTests}
          disabled={isRunning}
          className={`flex items-center gap-2 font-medium px-5 py-2.5 rounded-lg transition-all text-xs border cursor-pointer ${
            isRunning
              ? "bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed"
              : "bg-[#06038D] text-white border-[#06038D] hover:bg-[#06038D]/90 shadow-sm active:scale-95"
          }`}
          aria-label="Run validation scenarios"
        >
          {isRunning ? (
            <>
              <Loader2 className="animate-spin" size={14} />
              <span>Running Scenarios...</span>
            </>
          ) : (
            <>
              <Play fill="white" size={12} />
              <span>Run Sample Scenarios</span>
            </>
          )}
        </button>
      </div>

      <div className="bg-slate-50 border border-slate-100 rounded-lg p-3.5 text-xs text-slate-600 mb-4 flex gap-2">
        <Info size={16} className="text-slate-400 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          These automated tests send actual requests to the backend server's Gemini-3.5-Flash pipeline. 
          When a test passes, any generated civic complaints will automatically populate in your <strong>My Complaints</strong> tab!
        </p>
      </div>

      {overallStatus !== "idle" && (
        <div className={`mb-4 rounded-lg p-4 border flex items-center justify-between ${
          overallStatus === "running" ? "bg-amber-50 border-amber-200 text-amber-800" :
          overallStatus === "passed" ? "bg-emerald-50 border-emerald-200 text-emerald-800" :
          "bg-rose-50 border-rose-200 text-rose-800"
        }`}>
          <div className="flex items-center gap-2.5">
            {overallStatus === "running" && <Loader2 className="animate-spin text-amber-600" size={18} />}
            {overallStatus === "passed" && <CheckCircle2 className="text-emerald-600 font-bold" size={18} />}
            {overallStatus === "failed" && <XCircle className="text-rose-600 font-bold" size={18} />}
            <div>
              <span className="font-bold block">
                {overallStatus === "running" ? "Executing Test Runs..." :
                 overallStatus === "passed" ? "ALL SCENARIOS PASSED" :
                 "SOME TESTS ENCOUNTERED ERRORS"}
              </span>
              <span className="text-xs opacity-90">
                {overallStatus === "running" ? "Sending payloads to @google/genai..." :
                 overallStatus === "passed" ? "Excellent: Gemini returned perfectly parsable structured civic JSON objects." :
                 "Ensure your GEMINI_API_KEY is properly configured in Secrets."}
              </span>
            </div>
          </div>

          {overallStatus !== "running" && (
            <span className={`px-2.5 py-1 rounded-full text-xs font-black uppercase tracking-wider ${
              overallStatus === "passed" ? "bg-emerald-200 text-emerald-950" : "bg-rose-200 text-rose-950"
            }`}>
              {overallStatus === "passed" ? "PASS" : "FAIL"}
            </span>
          )}
        </div>
      )}

      <div className="space-y-3">
        {scenarios.map((sc, index) => (
          <div key={sc.id} className="border border-slate-200 rounded-lg overflow-hidden bg-white">
            <div className="flex items-center justify-between p-3 bg-slate-50 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500 font-mono">0{index + 1}</span>
                <h4 className="font-semibold text-slate-800 text-xs sm:text-sm">{sc.name}</h4>
              </div>

              <div className="flex items-center gap-2">
                {sc.status === "idle" && (
                  <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-500 border border-slate-200">
                    PENDING
                  </span>
                )}
                {sc.status === "running" && (
                  <span className="flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-50 text-amber-600 border border-amber-200">
                    <Loader2 className="animate-spin" size={10} /> RUNNING
                  </span>
                )}
                {sc.status === "passed" && (
                  <span className="flex items-center gap-0.5 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-700 border border-emerald-200">
                    <Check size={10} /> PASS
                  </span>
                )}
                {sc.status === "failed" && (
                  <span className="flex items-center gap-0.5 px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-700 border border-rose-200">
                    FAIL
                  </span>
                )}
              </div>
            </div>

            <div className="p-3 text-xs space-y-2">
              <p className="text-slate-500 leading-relaxed">{sc.description}</p>
              
              <div className="bg-slate-50 p-2.5 rounded border border-slate-100 text-[11px] font-mono whitespace-normal text-slate-600">
                <span className="text-[#FF9933] font-semibold block uppercase text-[9px] mb-0.5">Payload Query</span>
                "{sc.query}"
              </div>

              {sc.errorMessage && (
                <div className="text-[11px] text-rose-600 bg-rose-50/50 p-2 rounded border border-rose-100">
                  <strong>Error:</strong> {sc.errorMessage}
                </div>
              )}

              {sc.responsePreview && (
                <details className="mt-1">
                  <summary className="text-[10px] text-[#06038D] hover:underline cursor-pointer font-medium select-none flex items-center gap-0.5">
                    View Live JSON Response Schema
                    <ChevronRight size={10} className="inline rotate-90" />
                  </summary>
                  <pre className="mt-2 p-2.5 bg-slate-900 text-[#00FF66] rounded overflow-x-auto text-[10px] leading-relaxed max-h-48 scrollbar-thin">
                    {JSON.stringify(sc.responsePreview, null, 2)}
                  </pre>
                </details>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
